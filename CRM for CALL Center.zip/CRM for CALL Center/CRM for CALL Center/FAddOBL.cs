﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRM_for_CALL_Center
{
    
    public partial class FAddOBL : Form
    {
        BaseLPRDataSetTableAdapters.QueriesTableAdapter queriesTAdap;
        public FAddOBL()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            queriesTAdap = new BaseLPRDataSetTableAdapters.QueriesTableAdapter();
            if (tBID.Text == "" || tBObl.Text == "")
            { MessageBox.Show("Не введен параметр!"); }
            else
            {
                try
                {
                    queriesTAdap.AddObl(Convert.ToInt32(tBID.Text),tBObl.Text);
                    this.oblTableAdapter.Fill(this.baseLPRDataSet.Obl);
                    tBID.Clear();
                    tBObl.Clear();
                    this.oblTableAdapter.Adapter.Update(this.baseLPRDataSet.Obl);
                }
                catch { MessageBox.Show("Данные не добавлены!"); }
            }
        }

        private void FAddOBL_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.Obl". При необходимости она может быть перемещена или удалена.
            this.oblTableAdapter.Fill(this.baseLPRDataSet.Obl);

        }
    }
}
