﻿namespace CRM_for_CALL_Center
{
    partial class FAddSotr
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.tBID = new System.Windows.Forms.TextBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label13 = new System.Windows.Forms.Label();
            this.cBType = new System.Windows.Forms.ComboBox();
            this.tBPass = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tBLogin = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.butAdd = new System.Windows.Forms.Button();
            this.tBNumAdd = new System.Windows.Forms.TextBox();
            this.tBMailAdd = new System.Windows.Forms.TextBox();
            this.tBOtchAdd = new System.Windows.Forms.TextBox();
            this.tBFamAdd = new System.Windows.Forms.TextBox();
            this.tBNameAdd = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Bvz = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.butUpd = new System.Windows.Forms.Button();
            this.tBNumUPD = new System.Windows.Forms.TextBox();
            this.tBMailUPD = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.cBOtchUPD = new System.Windows.Forms.ComboBox();
            this.sotrydBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.baseLPRDataSet = new CRM_for_CALL_Center.BaseLPRDataSet();
            this.cBFamUPD = new System.Windows.Forms.ComboBox();
            this.cBNameUpd = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.butDELauto = new System.Windows.Forms.Button();
            this.butUPDAuto = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.tBPassUPD = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.cBTYPEupd = new System.Windows.Forms.ComboBox();
            this.cBLogUPD = new System.Windows.Forms.ComboBox();
            this.autorizationBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label14 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фАМИЛИЯDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.иМЯDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.оТЧЕСТВОDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.пОЧТАDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.нОМЕРТЕЛЕФОНАDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sOTRJOINBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sotrydTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.SotrydTableAdapter();
            this.sotrydJoinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sotrydJoinTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.SotrydJoinTableAdapter();
            this.autorizationTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.autorizationTableAdapter();
            this.sotrydJoinBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.sOTRJOINTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.SOTRJOINTableAdapter();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sotrydBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseLPRDataSet)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.autorizationBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sOTRJOINBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrydJoinBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrydJoinBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID:";
            // 
            // tBID
            // 
            this.tBID.Location = new System.Drawing.Point(6, 19);
            this.tBID.Name = "tBID";
            this.tBID.Size = new System.Drawing.Size(100, 20);
            this.tBID.TabIndex = 1;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(3, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(601, 123);
            this.tabControl1.TabIndex = 2;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.cBType);
            this.tabPage1.Controls.Add(this.tBPass);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.tBLogin);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.butAdd);
            this.tabPage1.Controls.Add(this.tBNumAdd);
            this.tabPage1.Controls.Add(this.tBMailAdd);
            this.tabPage1.Controls.Add(this.tBOtchAdd);
            this.tabPage1.Controls.Add(this.tBFamAdd);
            this.tabPage1.Controls.Add(this.tBNameAdd);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.Bvz);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.tBID);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(593, 97);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Добавление";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(461, 1);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(29, 13);
            this.label13.TabIndex = 18;
            this.label13.Text = "Тип:";
            // 
            // cBType
            // 
            this.cBType.FormattingEnabled = true;
            this.cBType.Items.AddRange(new object[] {
            "admin",
            "user"});
            this.cBType.Location = new System.Drawing.Point(464, 17);
            this.cBType.Name = "cBType";
            this.cBType.Size = new System.Drawing.Size(121, 21);
            this.cBType.TabIndex = 17;
            // 
            // tBPass
            // 
            this.tBPass.Location = new System.Drawing.Point(358, 61);
            this.tBPass.Name = "tBPass";
            this.tBPass.Size = new System.Drawing.Size(100, 20);
            this.tBPass.TabIndex = 16;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(358, 45);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(48, 13);
            this.label12.TabIndex = 15;
            this.label12.Text = "Пароль:";
            // 
            // tBLogin
            // 
            this.tBLogin.Location = new System.Drawing.Point(244, 62);
            this.tBLogin.Name = "tBLogin";
            this.tBLogin.Size = new System.Drawing.Size(100, 20);
            this.tBLogin.TabIndex = 14;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(244, 45);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 13);
            this.label11.TabIndex = 13;
            this.label11.Text = "Логин:";
            // 
            // butAdd
            // 
            this.butAdd.Location = new System.Drawing.Point(511, 62);
            this.butAdd.Name = "butAdd";
            this.butAdd.Size = new System.Drawing.Size(75, 23);
            this.butAdd.TabIndex = 12;
            this.butAdd.Text = "Добавить";
            this.butAdd.UseVisualStyleBackColor = true;
            this.butAdd.Click += new System.EventHandler(this.butAdd_Click);
            // 
            // tBNumAdd
            // 
            this.tBNumAdd.Location = new System.Drawing.Point(127, 62);
            this.tBNumAdd.Name = "tBNumAdd";
            this.tBNumAdd.Size = new System.Drawing.Size(100, 20);
            this.tBNumAdd.TabIndex = 11;
            // 
            // tBMailAdd
            // 
            this.tBMailAdd.Location = new System.Drawing.Point(6, 62);
            this.tBMailAdd.Name = "tBMailAdd";
            this.tBMailAdd.Size = new System.Drawing.Size(100, 20);
            this.tBMailAdd.TabIndex = 10;
            // 
            // tBOtchAdd
            // 
            this.tBOtchAdd.Location = new System.Drawing.Point(358, 18);
            this.tBOtchAdd.Name = "tBOtchAdd";
            this.tBOtchAdd.Size = new System.Drawing.Size(100, 20);
            this.tBOtchAdd.TabIndex = 9;
            // 
            // tBFamAdd
            // 
            this.tBFamAdd.Location = new System.Drawing.Point(126, 19);
            this.tBFamAdd.Name = "tBFamAdd";
            this.tBFamAdd.Size = new System.Drawing.Size(100, 20);
            this.tBFamAdd.TabIndex = 8;
            // 
            // tBNameAdd
            // 
            this.tBNameAdd.Location = new System.Drawing.Point(244, 18);
            this.tBNameAdd.Name = "tBNameAdd";
            this.tBNameAdd.Size = new System.Drawing.Size(100, 20);
            this.tBNameAdd.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(127, 45);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Номер телефона";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 46);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Почта:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(355, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Отчество:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(123, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Фамилия:";
            // 
            // Bvz
            // 
            this.Bvz.AutoSize = true;
            this.Bvz.Location = new System.Drawing.Point(241, 3);
            this.Bvz.Name = "Bvz";
            this.Bvz.Size = new System.Drawing.Size(32, 13);
            this.Bvz.TabIndex = 2;
            this.Bvz.Text = "Имя:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.butUpd);
            this.tabPage2.Controls.Add(this.tBNumUPD);
            this.tabPage2.Controls.Add(this.tBMailUPD);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.cBOtchUPD);
            this.tabPage2.Controls.Add(this.cBFamUPD);
            this.tabPage2.Controls.Add(this.cBNameUpd);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(593, 97);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Изменение";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // butUpd
            // 
            this.butUpd.Location = new System.Drawing.Point(394, 17);
            this.butUpd.Name = "butUpd";
            this.butUpd.Size = new System.Drawing.Size(108, 23);
            this.butUpd.TabIndex = 15;
            this.butUpd.Text = "Изменить данные";
            this.butUpd.UseVisualStyleBackColor = true;
            this.butUpd.Click += new System.EventHandler(this.butUpd_Click);
            // 
            // tBNumUPD
            // 
            this.tBNumUPD.Location = new System.Drawing.Point(115, 61);
            this.tBNumUPD.Name = "tBNumUPD";
            this.tBNumUPD.Size = new System.Drawing.Size(100, 20);
            this.tBNumUPD.TabIndex = 14;
            // 
            // tBMailUPD
            // 
            this.tBMailUPD.Location = new System.Drawing.Point(9, 61);
            this.tBMailUPD.Name = "tBMailUPD";
            this.tBMailUPD.Size = new System.Drawing.Size(100, 20);
            this.tBMailUPD.TabIndex = 13;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(112, 44);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 13);
            this.label9.TabIndex = 12;
            this.label9.Text = "Номер телефона";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 44);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(40, 13);
            this.label10.TabIndex = 11;
            this.label10.Text = "Почта:";
            // 
            // cBOtchUPD
            // 
            this.cBOtchUPD.DataSource = this.sotrydBindingSource;
            this.cBOtchUPD.DisplayMember = "Otch";
            this.cBOtchUPD.FormattingEnabled = true;
            this.cBOtchUPD.Location = new System.Drawing.Point(267, 19);
            this.cBOtchUPD.Name = "cBOtchUPD";
            this.cBOtchUPD.Size = new System.Drawing.Size(121, 21);
            this.cBOtchUPD.TabIndex = 10;
            this.cBOtchUPD.ValueMember = "ID";
            // 
            // sotrydBindingSource
            // 
            this.sotrydBindingSource.DataMember = "Sotryd";
            this.sotrydBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // baseLPRDataSet
            // 
            this.baseLPRDataSet.DataSetName = "BaseLPRDataSet";
            this.baseLPRDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cBFamUPD
            // 
            this.cBFamUPD.DataSource = this.sotrydBindingSource;
            this.cBFamUPD.DisplayMember = "Fam";
            this.cBFamUPD.FormattingEnabled = true;
            this.cBFamUPD.Location = new System.Drawing.Point(9, 20);
            this.cBFamUPD.Name = "cBFamUPD";
            this.cBFamUPD.Size = new System.Drawing.Size(121, 21);
            this.cBFamUPD.TabIndex = 9;
            this.cBFamUPD.ValueMember = "ID";
            // 
            // cBNameUpd
            // 
            this.cBNameUpd.DataSource = this.sotrydBindingSource;
            this.cBNameUpd.DisplayMember = "Name";
            this.cBNameUpd.FormattingEnabled = true;
            this.cBNameUpd.Location = new System.Drawing.Point(139, 20);
            this.cBNameUpd.Name = "cBNameUpd";
            this.cBNameUpd.Size = new System.Drawing.Size(121, 21);
            this.cBNameUpd.TabIndex = 8;
            this.cBNameUpd.ValueMember = "ID";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(264, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Отчество:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(59, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Фамилия:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(136, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(32, 13);
            this.label8.TabIndex = 5;
            this.label8.Text = "Имя:";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.butDELauto);
            this.tabPage3.Controls.Add(this.butUPDAuto);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.tBPassUPD);
            this.tabPage3.Controls.Add(this.label15);
            this.tabPage3.Controls.Add(this.cBTYPEupd);
            this.tabPage3.Controls.Add(this.cBLogUPD);
            this.tabPage3.Controls.Add(this.label14);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(593, 97);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Настройки авторизации";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // butDELauto
            // 
            this.butDELauto.Location = new System.Drawing.Point(486, 23);
            this.butDELauto.Name = "butDELauto";
            this.butDELauto.Size = new System.Drawing.Size(75, 23);
            this.butDELauto.TabIndex = 23;
            this.butDELauto.Text = "Удалить";
            this.butDELauto.UseVisualStyleBackColor = true;
            this.butDELauto.Click += new System.EventHandler(this.butDELauto_Click);
            // 
            // butUPDAuto
            // 
            this.butUPDAuto.Location = new System.Drawing.Point(405, 24);
            this.butUPDAuto.Name = "butUPDAuto";
            this.butUPDAuto.Size = new System.Drawing.Size(75, 23);
            this.butUPDAuto.TabIndex = 22;
            this.butUPDAuto.Text = "Изменить";
            this.butUPDAuto.UseVisualStyleBackColor = true;
            this.butUPDAuto.Click += new System.EventHandler(this.butUPDAuto_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(265, 10);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(103, 13);
            this.label16.TabIndex = 21;
            this.label16.Text = "Тип пользователя:";
            // 
            // tBPassUPD
            // 
            this.tBPassUPD.Location = new System.Drawing.Point(135, 26);
            this.tBPassUPD.Name = "tBPassUPD";
            this.tBPassUPD.Size = new System.Drawing.Size(124, 20);
            this.tBPassUPD.TabIndex = 20;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(136, 10);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(48, 13);
            this.label15.TabIndex = 19;
            this.label15.Text = "Пароль:";
            // 
            // cBTYPEupd
            // 
            this.cBTYPEupd.FormattingEnabled = true;
            this.cBTYPEupd.Items.AddRange(new object[] {
            "admin",
            "user"});
            this.cBTYPEupd.Location = new System.Drawing.Point(265, 26);
            this.cBTYPEupd.Name = "cBTYPEupd";
            this.cBTYPEupd.Size = new System.Drawing.Size(121, 21);
            this.cBTYPEupd.TabIndex = 18;
            // 
            // cBLogUPD
            // 
            this.cBLogUPD.DataSource = this.autorizationBindingSource;
            this.cBLogUPD.DisplayMember = "Login";
            this.cBLogUPD.FormattingEnabled = true;
            this.cBLogUPD.Location = new System.Drawing.Point(8, 26);
            this.cBLogUPD.Name = "cBLogUPD";
            this.cBLogUPD.Size = new System.Drawing.Size(121, 21);
            this.cBLogUPD.TabIndex = 17;
            // 
            // autorizationBindingSource
            // 
            this.autorizationBindingSource.DataMember = "autorization";
            this.autorizationBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(5, 10);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 13);
            this.label14.TabIndex = 16;
            this.label14.Text = "Логин:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.фАМИЛИЯDataGridViewTextBoxColumn,
            this.иМЯDataGridViewTextBoxColumn,
            this.оТЧЕСТВОDataGridViewTextBoxColumn,
            this.пОЧТАDataGridViewTextBoxColumn,
            this.нОМЕРТЕЛЕФОНАDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.sOTRJOINBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(3, 132);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(601, 263);
            this.dataGridView1.TabIndex = 3;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            // 
            // фАМИЛИЯDataGridViewTextBoxColumn
            // 
            this.фАМИЛИЯDataGridViewTextBoxColumn.DataPropertyName = "ФАМИЛИЯ";
            this.фАМИЛИЯDataGridViewTextBoxColumn.HeaderText = "ФАМИЛИЯ";
            this.фАМИЛИЯDataGridViewTextBoxColumn.Name = "фАМИЛИЯDataGridViewTextBoxColumn";
            // 
            // иМЯDataGridViewTextBoxColumn
            // 
            this.иМЯDataGridViewTextBoxColumn.DataPropertyName = "ИМЯ";
            this.иМЯDataGridViewTextBoxColumn.HeaderText = "ИМЯ";
            this.иМЯDataGridViewTextBoxColumn.Name = "иМЯDataGridViewTextBoxColumn";
            // 
            // оТЧЕСТВОDataGridViewTextBoxColumn
            // 
            this.оТЧЕСТВОDataGridViewTextBoxColumn.DataPropertyName = "ОТЧЕСТВО";
            this.оТЧЕСТВОDataGridViewTextBoxColumn.HeaderText = "ОТЧЕСТВО";
            this.оТЧЕСТВОDataGridViewTextBoxColumn.Name = "оТЧЕСТВОDataGridViewTextBoxColumn";
            // 
            // пОЧТАDataGridViewTextBoxColumn
            // 
            this.пОЧТАDataGridViewTextBoxColumn.DataPropertyName = "ПОЧТА";
            this.пОЧТАDataGridViewTextBoxColumn.HeaderText = "ПОЧТА";
            this.пОЧТАDataGridViewTextBoxColumn.Name = "пОЧТАDataGridViewTextBoxColumn";
            // 
            // нОМЕРТЕЛЕФОНАDataGridViewTextBoxColumn
            // 
            this.нОМЕРТЕЛЕФОНАDataGridViewTextBoxColumn.DataPropertyName = "НОМЕР ТЕЛЕФОНА";
            this.нОМЕРТЕЛЕФОНАDataGridViewTextBoxColumn.HeaderText = "НОМЕР ТЕЛЕФОНА";
            this.нОМЕРТЕЛЕФОНАDataGridViewTextBoxColumn.Name = "нОМЕРТЕЛЕФОНАDataGridViewTextBoxColumn";
            // 
            // sOTRJOINBindingSource
            // 
            this.sOTRJOINBindingSource.DataMember = "SOTRJOIN";
            this.sOTRJOINBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // sotrydTableAdapter
            // 
            this.sotrydTableAdapter.ClearBeforeFill = true;
            // 
            // sotrydJoinBindingSource
            // 
            this.sotrydJoinBindingSource.DataMember = "SotrydJoin";
            this.sotrydJoinBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // sotrydJoinTableAdapter
            // 
            this.sotrydJoinTableAdapter.ClearBeforeFill = true;
            // 
            // autorizationTableAdapter
            // 
            this.autorizationTableAdapter.ClearBeforeFill = true;
            // 
            // sotrydJoinBindingSource1
            // 
            this.sotrydJoinBindingSource1.DataMember = "SotrydJoin";
            this.sotrydJoinBindingSource1.DataSource = this.baseLPRDataSet;
            // 
            // sOTRJOINTableAdapter
            // 
            this.sOTRJOINTableAdapter.ClearBeforeFill = true;
            // 
            // FAddSotr
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(605, 407);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.tabControl1);
            this.Name = "FAddSotr";
            this.Text = "Сотрудники";
            this.Load += new System.EventHandler(this.FAddSotr_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sotrydBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseLPRDataSet)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.autorizationBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sOTRJOINBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrydJoinBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrydJoinBindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tBID;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button butAdd;
        private System.Windows.Forms.TextBox tBNumAdd;
        private System.Windows.Forms.TextBox tBMailAdd;
        private System.Windows.Forms.TextBox tBOtchAdd;
        private System.Windows.Forms.TextBox tBFamAdd;
        private System.Windows.Forms.TextBox tBNameAdd;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label Bvz;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button butUpd;
        private System.Windows.Forms.TextBox tBNumUPD;
        private System.Windows.Forms.TextBox tBMailUPD;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cBOtchUPD;
        private System.Windows.Forms.ComboBox cBFamUPD;
        private System.Windows.Forms.ComboBox cBNameUpd;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cBType;
        private System.Windows.Forms.TextBox tBPass;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tBLogin;
        private System.Windows.Forms.Label label11;
        private BaseLPRDataSet baseLPRDataSet;
        private System.Windows.Forms.BindingSource sotrydBindingSource;
        private BaseLPRDataSetTableAdapters.SotrydTableAdapter sotrydTableAdapter;
        private System.Windows.Forms.BindingSource sotrydJoinBindingSource;
        private BaseLPRDataSetTableAdapters.SotrydJoinTableAdapter sotrydJoinTableAdapter;
        private System.Windows.Forms.ComboBox cBLogUPD;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox tBPassUPD;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cBTYPEupd;
        private System.Windows.Forms.BindingSource autorizationBindingSource;
        private BaseLPRDataSetTableAdapters.autorizationTableAdapter autorizationTableAdapter;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button butDELauto;
        private System.Windows.Forms.Button butUPDAuto;
        private System.Windows.Forms.BindingSource sotrydJoinBindingSource1;
        private System.Windows.Forms.BindingSource sOTRJOINBindingSource;
        private BaseLPRDataSetTableAdapters.SOTRJOINTableAdapter sOTRJOINTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn фАМИЛИЯDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn иМЯDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn оТЧЕСТВОDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn пОЧТАDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn нОМЕРТЕЛЕФОНАDataGridViewTextBoxColumn;
    }
}