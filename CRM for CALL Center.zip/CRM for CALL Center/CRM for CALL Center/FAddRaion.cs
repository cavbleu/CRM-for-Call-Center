﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRM_for_CALL_Center
{
    public partial class FAddRaion : Form
    {

        BaseLPRDataSetTableAdapters.QueriesTableAdapter queriesTAdap;
        public FAddRaion()
        {
            InitializeComponent();
        }

        private void FAddRaion_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.RaionObl". При необходимости она может быть перемещена или удалена.
            this.raionOblTableAdapter.Fill(this.baseLPRDataSet.RaionObl);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.RaionJoin". При необходимости она может быть перемещена или удалена.
            this.raionJoinTableAdapter.Fill(this.baseLPRDataSet.RaionJoin);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.Obl". При необходимости она может быть перемещена или удалена.
            this.oblTableAdapter.Fill(this.baseLPRDataSet.Obl);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            queriesTAdap = new BaseLPRDataSetTableAdapters.QueriesTableAdapter();
            if (tBID.Text == "" || cBObl.Text == "" || textBox1.Text == "")
            { MessageBox.Show("Не введен параметр!"); }
            else
            {
                try
                {
                    queriesTAdap.AddRaion(Convert.ToInt32(tBID.Text), cBObl.Text, textBox1.Text);
                    this.raionJoinTableAdapter.Fill(this.baseLPRDataSet.RaionJoin);
                    //this.raionOblTableAdapter.Fill(this.baseLPRDataSet.Raion);
                    tBID.Clear();
                    textBox1.Clear();
                    this.raionJoinTableAdapter.Adapter.Update(this.baseLPRDataSet.RaionJoin);
                }
                catch { MessageBox.Show("Данные не добавлены!"); }
            }
        }
    }
}
