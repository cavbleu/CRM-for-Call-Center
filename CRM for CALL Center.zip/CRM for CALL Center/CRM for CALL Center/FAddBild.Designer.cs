﻿namespace CRM_for_CALL_Center
{
    partial class FAddBild
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.cBRc = new System.Windows.Forms.ComboBox();
            this.fKRaionCityBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.cityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.baseLPRDataSet = new CRM_for_CALL_Center.BaseLPRDataSet();
            this.label17 = new System.Windows.Forms.Label();
            this.cBCity = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.butAdd = new System.Windows.Forms.Button();
            this.cBnEq = new System.Windows.Forms.ComboBox();
            this.equiJoinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label7 = new System.Windows.Forms.Label();
            this.cBtPred = new System.Windows.Forms.ComboBox();
            this.cBtCab = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tBcountP = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cBNameStreet = new System.Windows.Forms.ComboBox();
            this.streetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label3 = new System.Windows.Forms.Label();
            this.tBNumBild = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tBID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.cBRcityUPD = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.cBEqUPD = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.butUPG = new System.Windows.Forms.Button();
            this.cBtechCUPD = new System.Windows.Forms.ComboBox();
            this.cBtechUPD = new System.Windows.Forms.ComboBox();
            this.tBportUPD = new System.Windows.Forms.TextBox();
            this.cBnumBUPD = new System.Windows.Forms.ComboBox();
            this.cBStreetUPD = new System.Windows.Forms.ComboBox();
            this.cBCityUPD = new System.Windows.Forms.ComboBox();
            this.cityBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.butDEL = new System.Windows.Forms.Button();
            this.cBnumBDEL = new System.Windows.Forms.ComboBox();
            this.bildingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cBStreetDEL = new System.Windows.Forms.ComboBox();
            this.cBCityDEL = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idBildingDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idEquipmentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.techСDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numportDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.technologyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cityTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.CityTableAdapter();
            this.streetTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.StreetTableAdapter();
            this.equiJoinTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.EquiJoinTableAdapter();
            this.bildingTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.BildingTableAdapter();
            this.baseLPRDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fKRaionCityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.raionTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.RaionTableAdapter();
            this.streetBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.fKStreetRaionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.raionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fKBildingStreetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fKBildingStreetBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.streetBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.fKBildingStreetBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.fKBildingStreetBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.fKORGBildingBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.oRGTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.ORGTableAdapter();
            this.label21 = new System.Windows.Forms.Label();
            this.cBRCityDel = new System.Windows.Forms.ComboBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fKRaionCityBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseLPRDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.equiJoinBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.streetBindingSource)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource1)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bildingBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseLPRDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKRaionCityBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.streetBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKStreetRaionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.raionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKBildingStreetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKBildingStreetBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.streetBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKBildingStreetBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKBildingStreetBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKORGBildingBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(3, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(757, 122);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.cBRc);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.cBCity);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.butAdd);
            this.tabPage1.Controls.Add(this.cBnEq);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.cBtPred);
            this.tabPage1.Controls.Add(this.cBtCab);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.tBcountP);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.cBNameStreet);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.tBNumBild);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.tBID);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(749, 96);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Добавление:";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // cBRc
            // 
            this.cBRc.DataSource = this.fKRaionCityBindingSource1;
            this.cBRc.DisplayMember = "NameR";
            this.cBRc.FormattingEnabled = true;
            this.cBRc.Location = new System.Drawing.Point(237, 20);
            this.cBRc.Name = "cBRc";
            this.cBRc.Size = new System.Drawing.Size(121, 21);
            this.cBRc.TabIndex = 19;
            this.cBRc.ValueMember = "idCity";
            // 
            // fKRaionCityBindingSource1
            // 
            this.fKRaionCityBindingSource1.DataMember = "FK_Raion_City";
            this.fKRaionCityBindingSource1.DataSource = this.cityBindingSource;
            // 
            // cityBindingSource
            // 
            this.cityBindingSource.DataMember = "City";
            this.cityBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // baseLPRDataSet
            // 
            this.baseLPRDataSet.DataSetName = "BaseLPRDataSet";
            this.baseLPRDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(240, 4);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(79, 13);
            this.label17.TabIndex = 18;
            this.label17.Text = "Район города:";
            // 
            // cBCity
            // 
            this.cBCity.DataSource = this.cityBindingSource;
            this.cBCity.DisplayMember = "Name";
            this.cBCity.FormattingEnabled = true;
            this.cBCity.Location = new System.Drawing.Point(110, 20);
            this.cBCity.Name = "cBCity";
            this.cBCity.Size = new System.Drawing.Size(121, 21);
            this.cBCity.TabIndex = 17;
            this.cBCity.ValueMember = "idCity";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(112, 4);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 13);
            this.label8.TabIndex = 16;
            this.label8.Text = "Город:";
            // 
            // butAdd
            // 
            this.butAdd.Location = new System.Drawing.Point(499, 62);
            this.butAdd.Name = "butAdd";
            this.butAdd.Size = new System.Drawing.Size(75, 23);
            this.butAdd.TabIndex = 15;
            this.butAdd.Text = "Добавить";
            this.butAdd.UseVisualStyleBackColor = true;
            this.butAdd.Click += new System.EventHandler(this.butAdd_Click);
            // 
            // cBnEq
            // 
            this.cBnEq.DataSource = this.equiJoinBindingSource;
            this.cBnEq.DisplayMember = "Name";
            this.cBnEq.FormattingEnabled = true;
            this.cBnEq.Location = new System.Drawing.Point(7, 64);
            this.cBnEq.Name = "cBnEq";
            this.cBnEq.Size = new System.Drawing.Size(134, 21);
            this.cBnEq.TabIndex = 14;
            // 
            // equiJoinBindingSource
            // 
            this.equiJoinBindingSource.DataMember = "EquiJoin";
            this.equiJoinBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 47);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(134, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Название оборудования:";
            // 
            // cBtPred
            // 
            this.cBtPred.FormattingEnabled = true;
            this.cBtPred.Items.AddRange(new object[] {
            "GPON",
            "ETTH",
            "xDSL"});
            this.cBtPred.Location = new System.Drawing.Point(274, 64);
            this.cBtPred.Name = "cBtPred";
            this.cBtPred.Size = new System.Drawing.Size(162, 21);
            this.cBtPred.TabIndex = 12;
            // 
            // cBtCab
            // 
            this.cBtCab.FormattingEnabled = true;
            this.cBtCab.Items.AddRange(new object[] {
            "PON",
            "UTP",
            "OTA"});
            this.cBtCab.Location = new System.Drawing.Point(147, 64);
            this.cBtCab.Name = "cBtCab";
            this.cBtCab.Size = new System.Drawing.Size(121, 21);
            this.cBtCab.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(274, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(165, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Название тех предоставления:";
            // 
            // tBcountP
            // 
            this.tBcountP.Location = new System.Drawing.Point(601, 20);
            this.tBcountP.Name = "tBcountP";
            this.tBcountP.Size = new System.Drawing.Size(100, 20);
            this.tBcountP.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(598, 4);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Кол-во портов:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(147, 47);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(118, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Название тех кабеля:";
            // 
            // cBNameStreet
            // 
            this.cBNameStreet.DataSource = this.fKStreetRaionBindingSource;
            this.cBNameStreet.DisplayMember = "NameS";
            this.cBNameStreet.FormattingEnabled = true;
            this.cBNameStreet.Location = new System.Drawing.Point(366, 20);
            this.cBNameStreet.Name = "cBNameStreet";
            this.cBNameStreet.Size = new System.Drawing.Size(121, 21);
            this.cBNameStreet.TabIndex = 5;
            this.cBNameStreet.ValueMember = "idStreet";
            // 
            // streetBindingSource
            // 
            this.streetBindingSource.DataMember = "Street";
            this.streetBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(363, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Название улицы:";
            // 
            // tBNumBild
            // 
            this.tBNumBild.Location = new System.Drawing.Point(495, 20);
            this.tBNumBild.Name = "tBNumBild";
            this.tBNumBild.Size = new System.Drawing.Size(100, 20);
            this.tBNumBild.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(492, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Номер дома:";
            // 
            // tBID
            // 
            this.tBID.Location = new System.Drawing.Point(6, 20);
            this.tBID.Name = "tBID";
            this.tBID.Size = new System.Drawing.Size(100, 20);
            this.tBID.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.cBRcityUPD);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.cBEqUPD);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Controls.Add(this.butUPG);
            this.tabPage2.Controls.Add(this.cBtechCUPD);
            this.tabPage2.Controls.Add(this.cBtechUPD);
            this.tabPage2.Controls.Add(this.tBportUPD);
            this.tabPage2.Controls.Add(this.cBnumBUPD);
            this.tabPage2.Controls.Add(this.cBStreetUPD);
            this.tabPage2.Controls.Add(this.cBCityUPD);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.label11);
            this.tabPage2.Controls.Add(this.label12);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(749, 96);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Обновление:";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // cBRcityUPD
            // 
            this.cBRcityUPD.DataSource = this.fKRaionCityBindingSource1;
            this.cBRcityUPD.DisplayMember = "NameR";
            this.cBRcityUPD.FormattingEnabled = true;
            this.cBRcityUPD.Location = new System.Drawing.Point(137, 18);
            this.cBRcityUPD.Name = "cBRcityUPD";
            this.cBRcityUPD.Size = new System.Drawing.Size(121, 21);
            this.cBRcityUPD.TabIndex = 35;
            this.cBRcityUPD.ValueMember = "idCity";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(134, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(79, 13);
            this.label20.TabIndex = 34;
            this.label20.Text = "Район города:";
            // 
            // cBEqUPD
            // 
            this.cBEqUPD.DataSource = this.equiJoinBindingSource;
            this.cBEqUPD.DisplayMember = "Name";
            this.cBEqUPD.FormattingEnabled = true;
            this.cBEqUPD.Location = new System.Drawing.Point(137, 59);
            this.cBEqUPD.Name = "cBEqUPD";
            this.cBEqUPD.Size = new System.Drawing.Size(121, 21);
            this.cBEqUPD.TabIndex = 33;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(134, 44);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(134, 13);
            this.label13.TabIndex = 32;
            this.label13.Text = "Название оборудования:";
            // 
            // butUPG
            // 
            this.butUPG.Location = new System.Drawing.Point(532, 60);
            this.butUPG.Name = "butUPG";
            this.butUPG.Size = new System.Drawing.Size(75, 23);
            this.butUPG.TabIndex = 31;
            this.butUPG.Text = "Выполнить";
            this.butUPG.UseVisualStyleBackColor = true;
            this.butUPG.Click += new System.EventHandler(this.butUPG_Click);
            // 
            // cBtechCUPD
            // 
            this.cBtechCUPD.FormattingEnabled = true;
            this.cBtechCUPD.Items.AddRange(new object[] {
            "PON",
            "UTP",
            "OTA"});
            this.cBtechCUPD.Location = new System.Drawing.Point(9, 60);
            this.cBtechCUPD.Name = "cBtechCUPD";
            this.cBtechCUPD.Size = new System.Drawing.Size(121, 21);
            this.cBtechCUPD.TabIndex = 30;
            // 
            // cBtechUPD
            // 
            this.cBtechUPD.FormattingEnabled = true;
            this.cBtechUPD.Items.AddRange(new object[] {
            "GPON",
            "ETTH",
            "xDSL"});
            this.cBtechUPD.Location = new System.Drawing.Point(275, 59);
            this.cBtechUPD.Name = "cBtechUPD";
            this.cBtechUPD.Size = new System.Drawing.Size(121, 21);
            this.cBtechUPD.TabIndex = 29;
            // 
            // tBportUPD
            // 
            this.tBportUPD.Location = new System.Drawing.Point(548, 20);
            this.tBportUPD.Name = "tBportUPD";
            this.tBportUPD.Size = new System.Drawing.Size(100, 20);
            this.tBportUPD.TabIndex = 28;
            // 
            // cBnumBUPD
            // 
            this.cBnumBUPD.DataSource = this.fKBildingStreetBindingSource3;
            this.cBnumBUPD.DisplayMember = "number";
            this.cBnumBUPD.FormattingEnabled = true;
            this.cBnumBUPD.Location = new System.Drawing.Point(420, 20);
            this.cBnumBUPD.Name = "cBnumBUPD";
            this.cBnumBUPD.Size = new System.Drawing.Size(121, 21);
            this.cBnumBUPD.TabIndex = 27;
            // 
            // cBStreetUPD
            // 
            this.cBStreetUPD.DataSource = this.fKStreetRaionBindingSource;
            this.cBStreetUPD.DisplayMember = "NameS";
            this.cBStreetUPD.FormattingEnabled = true;
            this.cBStreetUPD.Location = new System.Drawing.Point(274, 18);
            this.cBStreetUPD.Name = "cBStreetUPD";
            this.cBStreetUPD.Size = new System.Drawing.Size(121, 21);
            this.cBStreetUPD.TabIndex = 26;
            this.cBStreetUPD.ValueMember = "idStreet";
            // 
            // cBCityUPD
            // 
            this.cBCityUPD.DataSource = this.cityBindingSource1;
            this.cBCityUPD.DisplayMember = "Name";
            this.cBCityUPD.FormattingEnabled = true;
            this.cBCityUPD.Location = new System.Drawing.Point(9, 19);
            this.cBCityUPD.Name = "cBCityUPD";
            this.cBCityUPD.Size = new System.Drawing.Size(121, 21);
            this.cBCityUPD.TabIndex = 25;
            this.cBCityUPD.ValueMember = "idCity";
            // 
            // cityBindingSource1
            // 
            this.cityBindingSource1.DataMember = "City";
            this.cityBindingSource1.DataSource = this.baseLPRDataSet;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(272, 43);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(165, 13);
            this.label14.TabIndex = 23;
            this.label14.Text = "Название тех предоставления:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 43);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(118, 13);
            this.label15.TabIndex = 22;
            this.label15.Text = "Название тех кабеля:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(40, 13);
            this.label9.TabIndex = 21;
            this.label9.Text = "Город:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(549, 2);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 13);
            this.label10.TabIndex = 20;
            this.label10.Text = "Кол-во портов:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(272, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(94, 13);
            this.label11.TabIndex = 19;
            this.label11.Text = "Название улицы:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(417, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(73, 13);
            this.label12.TabIndex = 18;
            this.label12.Text = "Номер дома:";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.cBRCityDel);
            this.tabPage3.Controls.Add(this.label21);
            this.tabPage3.Controls.Add(this.butDEL);
            this.tabPage3.Controls.Add(this.cBnumBDEL);
            this.tabPage3.Controls.Add(this.cBStreetDEL);
            this.tabPage3.Controls.Add(this.cBCityDEL);
            this.tabPage3.Controls.Add(this.label16);
            this.tabPage3.Controls.Add(this.label18);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(749, 96);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Удаление:";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // butDEL
            // 
            this.butDEL.Location = new System.Drawing.Point(521, 24);
            this.butDEL.Name = "butDEL";
            this.butDEL.Size = new System.Drawing.Size(75, 23);
            this.butDEL.TabIndex = 31;
            this.butDEL.Text = "Удалить";
            this.butDEL.UseVisualStyleBackColor = true;
            this.butDEL.Click += new System.EventHandler(this.butDEL_Click);
            // 
            // cBnumBDEL
            // 
            this.cBnumBDEL.DataSource = this.bildingBindingSource;
            this.cBnumBDEL.DisplayMember = "number";
            this.cBnumBDEL.FormattingEnabled = true;
            this.cBnumBDEL.Location = new System.Drawing.Point(394, 26);
            this.cBnumBDEL.Name = "cBnumBDEL";
            this.cBnumBDEL.Size = new System.Drawing.Size(121, 21);
            this.cBnumBDEL.TabIndex = 30;
            // 
            // bildingBindingSource
            // 
            this.bildingBindingSource.DataMember = "Bilding";
            this.bildingBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // cBStreetDEL
            // 
            this.cBStreetDEL.DataSource = this.streetBindingSource;
            this.cBStreetDEL.DisplayMember = "NameS";
            this.cBStreetDEL.FormattingEnabled = true;
            this.cBStreetDEL.Location = new System.Drawing.Point(266, 26);
            this.cBStreetDEL.Name = "cBStreetDEL";
            this.cBStreetDEL.Size = new System.Drawing.Size(121, 21);
            this.cBStreetDEL.TabIndex = 29;
            this.cBStreetDEL.ValueMember = "idStreet";
            // 
            // cBCityDEL
            // 
            this.cBCityDEL.DataSource = this.cityBindingSource;
            this.cBCityDEL.DisplayMember = "Name";
            this.cBCityDEL.FormattingEnabled = true;
            this.cBCityDEL.Location = new System.Drawing.Point(8, 26);
            this.cBCityDEL.Name = "cBCityDEL";
            this.cBCityDEL.Size = new System.Drawing.Size(121, 21);
            this.cBCityDEL.TabIndex = 28;
            this.cBCityDEL.ValueMember = "idCity";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(5, 9);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(40, 13);
            this.label16.TabIndex = 27;
            this.label16.Text = "Город:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(263, 9);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(94, 13);
            this.label18.TabIndex = 25;
            this.label18.Text = "Название улицы:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(391, 10);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(73, 13);
            this.label19.TabIndex = 24;
            this.label19.Text = "Номер дома:";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idBildingDataGridViewTextBoxColumn,
            this.idEquipmentDataGridViewTextBoxColumn,
            this.techСDataGridViewTextBoxColumn,
            this.numportDataGridViewTextBoxColumn,
            this.technologyDataGridViewTextBoxColumn,
            this.numberDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.bildingBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 132);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(735, 339);
            this.dataGridView1.TabIndex = 15;
            // 
            // idBildingDataGridViewTextBoxColumn
            // 
            this.idBildingDataGridViewTextBoxColumn.DataPropertyName = "idBilding";
            this.idBildingDataGridViewTextBoxColumn.HeaderText = "idBilding";
            this.idBildingDataGridViewTextBoxColumn.Name = "idBildingDataGridViewTextBoxColumn";
            // 
            // idEquipmentDataGridViewTextBoxColumn
            // 
            this.idEquipmentDataGridViewTextBoxColumn.DataPropertyName = "idEquipment";
            this.idEquipmentDataGridViewTextBoxColumn.HeaderText = "idEquipment";
            this.idEquipmentDataGridViewTextBoxColumn.Name = "idEquipmentDataGridViewTextBoxColumn";
            // 
            // techСDataGridViewTextBoxColumn
            // 
            this.techСDataGridViewTextBoxColumn.DataPropertyName = "techС";
            this.techСDataGridViewTextBoxColumn.HeaderText = "techС";
            this.techСDataGridViewTextBoxColumn.Name = "techСDataGridViewTextBoxColumn";
            // 
            // numportDataGridViewTextBoxColumn
            // 
            this.numportDataGridViewTextBoxColumn.DataPropertyName = "numport";
            this.numportDataGridViewTextBoxColumn.HeaderText = "numport";
            this.numportDataGridViewTextBoxColumn.Name = "numportDataGridViewTextBoxColumn";
            // 
            // technologyDataGridViewTextBoxColumn
            // 
            this.technologyDataGridViewTextBoxColumn.DataPropertyName = "technology";
            this.technologyDataGridViewTextBoxColumn.HeaderText = "technology";
            this.technologyDataGridViewTextBoxColumn.Name = "technologyDataGridViewTextBoxColumn";
            // 
            // numberDataGridViewTextBoxColumn
            // 
            this.numberDataGridViewTextBoxColumn.DataPropertyName = "number";
            this.numberDataGridViewTextBoxColumn.HeaderText = "number";
            this.numberDataGridViewTextBoxColumn.Name = "numberDataGridViewTextBoxColumn";
            // 
            // cityTableAdapter
            // 
            this.cityTableAdapter.ClearBeforeFill = true;
            // 
            // streetTableAdapter
            // 
            this.streetTableAdapter.ClearBeforeFill = true;
            // 
            // equiJoinTableAdapter
            // 
            this.equiJoinTableAdapter.ClearBeforeFill = true;
            // 
            // bildingTableAdapter
            // 
            this.bildingTableAdapter.ClearBeforeFill = true;
            // 
            // baseLPRDataSetBindingSource
            // 
            this.baseLPRDataSetBindingSource.DataSource = this.baseLPRDataSet;
            this.baseLPRDataSetBindingSource.Position = 0;
            // 
            // fKRaionCityBindingSource
            // 
            this.fKRaionCityBindingSource.DataMember = "FK_Raion_City";
            this.fKRaionCityBindingSource.DataSource = this.cityBindingSource;
            // 
            // raionTableAdapter
            // 
            this.raionTableAdapter.ClearBeforeFill = true;
            // 
            // streetBindingSource1
            // 
            this.streetBindingSource1.DataMember = "Street";
            this.streetBindingSource1.DataSource = this.baseLPRDataSet;
            // 
            // fKStreetRaionBindingSource
            // 
            this.fKStreetRaionBindingSource.DataMember = "FK_Street_Raion";
            this.fKStreetRaionBindingSource.DataSource = this.fKRaionCityBindingSource1;
            // 
            // raionBindingSource
            // 
            this.raionBindingSource.DataMember = "Raion";
            this.raionBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // fKBildingStreetBindingSource
            // 
            this.fKBildingStreetBindingSource.DataMember = "FK_Bilding_Street";
            this.fKBildingStreetBindingSource.DataSource = this.fKStreetRaionBindingSource;
            // 
            // fKBildingStreetBindingSource1
            // 
            this.fKBildingStreetBindingSource1.DataMember = "FK_Bilding_Street";
            this.fKBildingStreetBindingSource1.DataSource = this.fKStreetRaionBindingSource;
            // 
            // streetBindingSource2
            // 
            this.streetBindingSource2.DataMember = "Street";
            this.streetBindingSource2.DataSource = this.baseLPRDataSet;
            // 
            // fKBildingStreetBindingSource2
            // 
            this.fKBildingStreetBindingSource2.DataMember = "FK_Bilding_Street";
            this.fKBildingStreetBindingSource2.DataSource = this.fKStreetRaionBindingSource;
            // 
            // fKBildingStreetBindingSource3
            // 
            this.fKBildingStreetBindingSource3.DataMember = "FK_Bilding_Street";
            this.fKBildingStreetBindingSource3.DataSource = this.fKStreetRaionBindingSource;
            // 
            // fKORGBildingBindingSource
            // 
            this.fKORGBildingBindingSource.DataMember = "FK_ORG_Bilding";
            this.fKORGBildingBindingSource.DataSource = this.fKBildingStreetBindingSource2;
            // 
            // oRGTableAdapter
            // 
            this.oRGTableAdapter.ClearBeforeFill = true;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(137, 8);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(79, 13);
            this.label21.TabIndex = 32;
            this.label21.Text = "Район города:";
            // 
            // cBRCityDel
            // 
            this.cBRCityDel.DataSource = this.fKRaionCityBindingSource1;
            this.cBRCityDel.DisplayMember = "NameR";
            this.cBRCityDel.FormattingEnabled = true;
            this.cBRCityDel.Location = new System.Drawing.Point(140, 25);
            this.cBRCityDel.Name = "cBRCityDel";
            this.cBRCityDel.Size = new System.Drawing.Size(121, 21);
            this.cBRCityDel.TabIndex = 33;
            this.cBRCityDel.ValueMember = "idCity";
            // 
            // FAddBild
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(760, 483);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.tabControl1);
            this.Name = "FAddBild";
            this.Text = "Форма редактирования инф дома";
            this.Load += new System.EventHandler(this.FAddBild_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fKRaionCityBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseLPRDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.equiJoinBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.streetBindingSource)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource1)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bildingBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseLPRDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKRaionCityBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.streetBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKStreetRaionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.raionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKBildingStreetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKBildingStreetBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.streetBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKBildingStreetBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKBildingStreetBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKORGBildingBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button butAdd;
        private System.Windows.Forms.ComboBox cBnEq;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cBtPred;
        private System.Windows.Forms.ComboBox cBtCab;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox tBcountP;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cBNameStreet;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tBNumBild;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tBID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox cBCity;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button butUPG;
        private System.Windows.Forms.ComboBox cBtechCUPD;
        private System.Windows.Forms.ComboBox cBtechUPD;
        private System.Windows.Forms.TextBox tBportUPD;
        private System.Windows.Forms.ComboBox cBnumBUPD;
        private System.Windows.Forms.ComboBox cBStreetUPD;
        private System.Windows.Forms.ComboBox cBCityUPD;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button butDEL;
        private System.Windows.Forms.ComboBox cBnumBDEL;
        private System.Windows.Forms.ComboBox cBStreetDEL;
        private System.Windows.Forms.ComboBox cBCityDEL;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private BaseLPRDataSet baseLPRDataSet;
        private System.Windows.Forms.BindingSource cityBindingSource;
        private BaseLPRDataSetTableAdapters.CityTableAdapter cityTableAdapter;
        private System.Windows.Forms.BindingSource streetBindingSource;
        private BaseLPRDataSetTableAdapters.StreetTableAdapter streetTableAdapter;
        private System.Windows.Forms.BindingSource equiJoinBindingSource;
        private BaseLPRDataSetTableAdapters.EquiJoinTableAdapter equiJoinTableAdapter;
        private System.Windows.Forms.BindingSource bildingBindingSource;
        private BaseLPRDataSetTableAdapters.BildingTableAdapter bildingTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idBildingDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idEquipmentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn techСDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numportDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn technologyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn numberDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource baseLPRDataSetBindingSource;
        private System.Windows.Forms.ComboBox cBEqUPD;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.BindingSource fKRaionCityBindingSource;
        private BaseLPRDataSetTableAdapters.RaionTableAdapter raionTableAdapter;
        private System.Windows.Forms.BindingSource cityBindingSource1;
        private System.Windows.Forms.BindingSource streetBindingSource1;
        private System.Windows.Forms.BindingSource fKRaionCityBindingSource1;
        private System.Windows.Forms.ComboBox cBRc;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.ComboBox cBRcityUPD;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.BindingSource fKStreetRaionBindingSource;
        private System.Windows.Forms.BindingSource raionBindingSource;
        private System.Windows.Forms.BindingSource fKBildingStreetBindingSource;
        private System.Windows.Forms.BindingSource fKBildingStreetBindingSource1;
        private System.Windows.Forms.BindingSource streetBindingSource2;
        private System.Windows.Forms.BindingSource fKBildingStreetBindingSource2;
        private System.Windows.Forms.BindingSource fKBildingStreetBindingSource3;
        private System.Windows.Forms.BindingSource fKORGBildingBindingSource;
        private BaseLPRDataSetTableAdapters.ORGTableAdapter oRGTableAdapter;
        private System.Windows.Forms.ComboBox cBRCityDel;
        private System.Windows.Forms.Label label21;
    }
}