﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRM_for_CALL_Center
{
    public partial class FAddCity : Form
    {

        BaseLPRDataSetTableAdapters.QueriesTableAdapter queriesTAdap;
        public FAddCity()
        {
            InitializeComponent();
        }

        private void FAddCity_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.City". При необходимости она может быть перемещена или удалена.
            this.cityTableAdapter.Fill(this.baseLPRDataSet.City);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.RaionObl". При необходимости она может быть перемещена или удалена.
            this.raionOblTableAdapter.Fill(this.baseLPRDataSet.RaionObl);

            this.cityJoinTableAdapter.Fill(this.baseLPRDataSet.CityJoin, "");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            queriesTAdap = new BaseLPRDataSetTableAdapters.QueriesTableAdapter();
            if (tBID.Text == "" || cBRaion.Text == "" || tBCity.Text == "")
            { MessageBox.Show("Не введен параметр!"); }
            else
            {
                try
                {
                    queriesTAdap.AddCity(Convert.ToInt32(tBID.Text), tBCity.Text,cBRaion.Text);
                    this.cityTableAdapter.Fill(this.baseLPRDataSet.City);
                    this.cityJoinTableAdapter.Fill(this.baseLPRDataSet.CityJoin,"");
                    tBID.Clear();
                    tBCity.Clear();
                    this.cityJoinTableAdapter.Adapter.Update(this.baseLPRDataSet.CityJoin);
                    this.cityTableAdapter.Adapter.Update(this.baseLPRDataSet.City);
                }
                catch { MessageBox.Show("Данные не добавлены!"); }
            }
        }
    }
}
