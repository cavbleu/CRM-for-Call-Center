﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRM_for_CALL_Center
{
    public partial class FAddRCity : Form
    {

        BaseLPRDataSetTableAdapters.QueriesTableAdapter queriesTAdap;
        public FAddRCity()
        {
            InitializeComponent();
        }

        private void FAddRCity_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.City". При необходимости она может быть перемещена или удалена.
            this.cityTableAdapter.Fill(this.baseLPRDataSet.City);

            this.cityRJoinTableAdapter.Fill(this.baseLPRDataSet.CityRJoin, "", "");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            queriesTAdap = new BaseLPRDataSetTableAdapters.QueriesTableAdapter();
            if (tBID.Text == "" || cBCity.Text == "" || textBox1.Text == "")
            { MessageBox.Show("Не введен параметр!"); }
            else
            {
                try
                {
                    queriesTAdap.AddRaionCity(Convert.ToInt32(tBID.Text), textBox1.Text, cBCity.Text);
                    this.cityRJoinTableAdapter.Fill(this.baseLPRDataSet.CityRJoin,"","");
                    //this.cityJoinTableAdapter.Fill(this.baseLPRDataSet.CityJoin, "");
                    tBID.Clear();
                    textBox1.Clear();
                    this.cityRJoinTableAdapter.Adapter.Update(this.baseLPRDataSet.City);
                    //this.cityTableAdapter.Adapter.Update(this.baseLPRDataSet.City);
                }
                catch { MessageBox.Show("Данные не добавлены!"); }
            }
        }
    }
}
