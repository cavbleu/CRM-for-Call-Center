﻿namespace CRM_for_CALL_Center
{
    partial class FUserG
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.правкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьРайонГородаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьУлицуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьДомToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьОрганизациюToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.формированиеОтчетаПоГородуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.формированиеОтчетаПоРайонуГородаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.формированиеОтчетаПоОрганизацииToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.названиеОрганизацииDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.статусDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.описаниеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фАМИЛИЯЛПРDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.иМЯЛПРDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.почтаЛПРDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.нормерТелЛПРDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.областьDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.районОбластиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.населенныйПунктDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеРнаГородаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.улицаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерДомаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.технологияПредосталенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.технологияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.почтаОрганизацииDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерТелефонаОргDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фамилияСотрудникаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.имяСотрудникаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oRGJoinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.baseLPRDataSet = new CRM_for_CALL_Center.BaseLPRDataSet();
            this.label1 = new System.Windows.Forms.Label();
            this.tBCity = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tBCRaion = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tBCStreet = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cBORG = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cBStatus = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.bFilter = new System.Windows.Forms.Button();
            this.oRGJoinTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.ORGJoinTableAdapter();
            this.cBNameSotr = new System.Windows.Forms.ComboBox();
            this.cBFamSotr = new System.Windows.Forms.ComboBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oRGJoinBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseLPRDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.правкаToolStripMenuItem,
            this.отчетыToolStripMenuItem,
            this.выходToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1171, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // правкаToolStripMenuItem
            // 
            this.правкаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.добавитьРайонГородаToolStripMenuItem,
            this.добавитьУлицуToolStripMenuItem,
            this.добавитьДомToolStripMenuItem,
            this.добавитьОрганизациюToolStripMenuItem});
            this.правкаToolStripMenuItem.Name = "правкаToolStripMenuItem";
            this.правкаToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.правкаToolStripMenuItem.Text = "Правка";
            // 
            // добавитьРайонГородаToolStripMenuItem
            // 
            this.добавитьРайонГородаToolStripMenuItem.Name = "добавитьРайонГородаToolStripMenuItem";
            this.добавитьРайонГородаToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.добавитьРайонГородаToolStripMenuItem.Text = "Добавить район города";
            this.добавитьРайонГородаToolStripMenuItem.Click += new System.EventHandler(this.добавитьРайонГородаToolStripMenuItem_Click);
            // 
            // добавитьУлицуToolStripMenuItem
            // 
            this.добавитьУлицуToolStripMenuItem.Name = "добавитьУлицуToolStripMenuItem";
            this.добавитьУлицуToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.добавитьУлицуToolStripMenuItem.Text = "Добавить улицу";
            this.добавитьУлицуToolStripMenuItem.Click += new System.EventHandler(this.добавитьУлицуToolStripMenuItem_Click);
            // 
            // добавитьДомToolStripMenuItem
            // 
            this.добавитьДомToolStripMenuItem.Name = "добавитьДомToolStripMenuItem";
            this.добавитьДомToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.добавитьДомToolStripMenuItem.Text = "Добавить дом";
            this.добавитьДомToolStripMenuItem.Click += new System.EventHandler(this.добавитьДомToolStripMenuItem_Click);
            // 
            // добавитьОрганизациюToolStripMenuItem
            // 
            this.добавитьОрганизациюToolStripMenuItem.Name = "добавитьОрганизациюToolStripMenuItem";
            this.добавитьОрганизациюToolStripMenuItem.Size = new System.Drawing.Size(204, 22);
            this.добавитьОрганизациюToolStripMenuItem.Text = "Добавить организацию";
            this.добавитьОрганизациюToolStripMenuItem.Click += new System.EventHandler(this.добавитьОрганизациюToolStripMenuItem_Click);
            // 
            // отчетыToolStripMenuItem
            // 
            this.отчетыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.формированиеОтчетаПоГородуToolStripMenuItem,
            this.формированиеОтчетаПоРайонуГородаToolStripMenuItem,
            this.формированиеОтчетаПоОрганизацииToolStripMenuItem});
            this.отчетыToolStripMenuItem.Name = "отчетыToolStripMenuItem";
            this.отчетыToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.отчетыToolStripMenuItem.Text = "Отчеты";
            // 
            // формированиеОтчетаПоГородуToolStripMenuItem
            // 
            this.формированиеОтчетаПоГородуToolStripMenuItem.Name = "формированиеОтчетаПоГородуToolStripMenuItem";
            this.формированиеОтчетаПоГородуToolStripMenuItem.Size = new System.Drawing.Size(299, 22);
            this.формированиеОтчетаПоГородуToolStripMenuItem.Text = "Формирование отчета по городу";
            this.формированиеОтчетаПоГородуToolStripMenuItem.Click += new System.EventHandler(this.формированиеОтчетаПоГородуToolStripMenuItem_Click);
            // 
            // формированиеОтчетаПоРайонуГородаToolStripMenuItem
            // 
            this.формированиеОтчетаПоРайонуГородаToolStripMenuItem.Name = "формированиеОтчетаПоРайонуГородаToolStripMenuItem";
            this.формированиеОтчетаПоРайонуГородаToolStripMenuItem.Size = new System.Drawing.Size(299, 22);
            this.формированиеОтчетаПоРайонуГородаToolStripMenuItem.Text = "Формирование отчета по району города";
            this.формированиеОтчетаПоРайонуГородаToolStripMenuItem.Click += new System.EventHandler(this.формированиеОтчетаПоРайонуГородаToolStripMenuItem_Click);
            // 
            // формированиеОтчетаПоОрганизацииToolStripMenuItem
            // 
            this.формированиеОтчетаПоОрганизацииToolStripMenuItem.Name = "формированиеОтчетаПоОрганизацииToolStripMenuItem";
            this.формированиеОтчетаПоОрганизацииToolStripMenuItem.Size = new System.Drawing.Size(299, 22);
            this.формированиеОтчетаПоОрганизацииToolStripMenuItem.Text = "Формирование отчета по организации";
            this.формированиеОтчетаПоОрганизацииToolStripMenuItem.Click += new System.EventHandler(this.формированиеОтчетаПоОрганизацииToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.названиеОрганизацииDataGridViewTextBoxColumn,
            this.статусDataGridViewTextBoxColumn,
            this.описаниеDataGridViewTextBoxColumn,
            this.фАМИЛИЯЛПРDataGridViewTextBoxColumn,
            this.иМЯЛПРDataGridViewTextBoxColumn,
            this.почтаЛПРDataGridViewTextBoxColumn,
            this.нормерТелЛПРDataGridViewTextBoxColumn,
            this.областьDataGridViewTextBoxColumn,
            this.районОбластиDataGridViewTextBoxColumn,
            this.населенныйПунктDataGridViewTextBoxColumn,
            this.названиеРнаГородаDataGridViewTextBoxColumn,
            this.улицаDataGridViewTextBoxColumn,
            this.номерДомаDataGridViewTextBoxColumn,
            this.технологияПредосталенияDataGridViewTextBoxColumn,
            this.технологияDataGridViewTextBoxColumn,
            this.почтаОрганизацииDataGridViewTextBoxColumn,
            this.номерТелефонаОргDataGridViewTextBoxColumn,
            this.фамилияСотрудникаDataGridViewTextBoxColumn,
            this.имяСотрудникаDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.oRGJoinBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(13, 91);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1146, 479);
            this.dataGridView1.TabIndex = 1;
            // 
            // названиеОрганизацииDataGridViewTextBoxColumn
            // 
            this.названиеОрганизацииDataGridViewTextBoxColumn.DataPropertyName = "Название организации";
            this.названиеОрганизацииDataGridViewTextBoxColumn.HeaderText = "Название организации";
            this.названиеОрганизацииDataGridViewTextBoxColumn.Name = "названиеОрганизацииDataGridViewTextBoxColumn";
            // 
            // статусDataGridViewTextBoxColumn
            // 
            this.статусDataGridViewTextBoxColumn.DataPropertyName = "Статус";
            this.статусDataGridViewTextBoxColumn.HeaderText = "Статус";
            this.статусDataGridViewTextBoxColumn.Name = "статусDataGridViewTextBoxColumn";
            // 
            // описаниеDataGridViewTextBoxColumn
            // 
            this.описаниеDataGridViewTextBoxColumn.DataPropertyName = "Описание";
            this.описаниеDataGridViewTextBoxColumn.HeaderText = "Описание";
            this.описаниеDataGridViewTextBoxColumn.Name = "описаниеDataGridViewTextBoxColumn";
            // 
            // фАМИЛИЯЛПРDataGridViewTextBoxColumn
            // 
            this.фАМИЛИЯЛПРDataGridViewTextBoxColumn.DataPropertyName = "ФАМИЛИЯ ЛПР";
            this.фАМИЛИЯЛПРDataGridViewTextBoxColumn.HeaderText = "ФАМИЛИЯ ЛПР";
            this.фАМИЛИЯЛПРDataGridViewTextBoxColumn.Name = "фАМИЛИЯЛПРDataGridViewTextBoxColumn";
            // 
            // иМЯЛПРDataGridViewTextBoxColumn
            // 
            this.иМЯЛПРDataGridViewTextBoxColumn.DataPropertyName = "ИМЯ ЛПР";
            this.иМЯЛПРDataGridViewTextBoxColumn.HeaderText = "ИМЯ ЛПР";
            this.иМЯЛПРDataGridViewTextBoxColumn.Name = "иМЯЛПРDataGridViewTextBoxColumn";
            // 
            // почтаЛПРDataGridViewTextBoxColumn
            // 
            this.почтаЛПРDataGridViewTextBoxColumn.DataPropertyName = "Почта ЛПР";
            this.почтаЛПРDataGridViewTextBoxColumn.HeaderText = "Почта ЛПР";
            this.почтаЛПРDataGridViewTextBoxColumn.Name = "почтаЛПРDataGridViewTextBoxColumn";
            // 
            // нормерТелЛПРDataGridViewTextBoxColumn
            // 
            this.нормерТелЛПРDataGridViewTextBoxColumn.DataPropertyName = "Нормер тел ЛПР";
            this.нормерТелЛПРDataGridViewTextBoxColumn.HeaderText = "Нормер тел ЛПР";
            this.нормерТелЛПРDataGridViewTextBoxColumn.Name = "нормерТелЛПРDataGridViewTextBoxColumn";
            // 
            // областьDataGridViewTextBoxColumn
            // 
            this.областьDataGridViewTextBoxColumn.DataPropertyName = "Область";
            this.областьDataGridViewTextBoxColumn.HeaderText = "Область";
            this.областьDataGridViewTextBoxColumn.Name = "областьDataGridViewTextBoxColumn";
            // 
            // районОбластиDataGridViewTextBoxColumn
            // 
            this.районОбластиDataGridViewTextBoxColumn.DataPropertyName = "Район области";
            this.районОбластиDataGridViewTextBoxColumn.HeaderText = "Район области";
            this.районОбластиDataGridViewTextBoxColumn.Name = "районОбластиDataGridViewTextBoxColumn";
            // 
            // населенныйПунктDataGridViewTextBoxColumn
            // 
            this.населенныйПунктDataGridViewTextBoxColumn.DataPropertyName = "Населенный пункт";
            this.населенныйПунктDataGridViewTextBoxColumn.HeaderText = "Населенный пункт";
            this.населенныйПунктDataGridViewTextBoxColumn.Name = "населенныйПунктDataGridViewTextBoxColumn";
            // 
            // названиеРнаГородаDataGridViewTextBoxColumn
            // 
            this.названиеРнаГородаDataGridViewTextBoxColumn.DataPropertyName = "Название р-на города";
            this.названиеРнаГородаDataGridViewTextBoxColumn.HeaderText = "Название р-на города";
            this.названиеРнаГородаDataGridViewTextBoxColumn.Name = "названиеРнаГородаDataGridViewTextBoxColumn";
            // 
            // улицаDataGridViewTextBoxColumn
            // 
            this.улицаDataGridViewTextBoxColumn.DataPropertyName = "Улица";
            this.улицаDataGridViewTextBoxColumn.HeaderText = "Улица";
            this.улицаDataGridViewTextBoxColumn.Name = "улицаDataGridViewTextBoxColumn";
            // 
            // номерДомаDataGridViewTextBoxColumn
            // 
            this.номерДомаDataGridViewTextBoxColumn.DataPropertyName = "Номер дома";
            this.номерДомаDataGridViewTextBoxColumn.HeaderText = "Номер дома";
            this.номерДомаDataGridViewTextBoxColumn.Name = "номерДомаDataGridViewTextBoxColumn";
            // 
            // технологияПредосталенияDataGridViewTextBoxColumn
            // 
            this.технологияПредосталенияDataGridViewTextBoxColumn.DataPropertyName = "Технология предосталения";
            this.технологияПредосталенияDataGridViewTextBoxColumn.HeaderText = "Технология предосталения";
            this.технологияПредосталенияDataGridViewTextBoxColumn.Name = "технологияПредосталенияDataGridViewTextBoxColumn";
            // 
            // технологияDataGridViewTextBoxColumn
            // 
            this.технологияDataGridViewTextBoxColumn.DataPropertyName = "Технология";
            this.технологияDataGridViewTextBoxColumn.HeaderText = "Технология";
            this.технологияDataGridViewTextBoxColumn.Name = "технологияDataGridViewTextBoxColumn";
            // 
            // почтаОрганизацииDataGridViewTextBoxColumn
            // 
            this.почтаОрганизацииDataGridViewTextBoxColumn.DataPropertyName = "Почта организации";
            this.почтаОрганизацииDataGridViewTextBoxColumn.HeaderText = "Почта организации";
            this.почтаОрганизацииDataGridViewTextBoxColumn.Name = "почтаОрганизацииDataGridViewTextBoxColumn";
            // 
            // номерТелефонаОргDataGridViewTextBoxColumn
            // 
            this.номерТелефонаОргDataGridViewTextBoxColumn.DataPropertyName = "Номер телефона орг";
            this.номерТелефонаОргDataGridViewTextBoxColumn.HeaderText = "Номер телефона орг";
            this.номерТелефонаОргDataGridViewTextBoxColumn.Name = "номерТелефонаОргDataGridViewTextBoxColumn";
            // 
            // фамилияСотрудникаDataGridViewTextBoxColumn
            // 
            this.фамилияСотрудникаDataGridViewTextBoxColumn.DataPropertyName = "Фамилия сотрудника";
            this.фамилияСотрудникаDataGridViewTextBoxColumn.HeaderText = "Фамилия сотрудника";
            this.фамилияСотрудникаDataGridViewTextBoxColumn.Name = "фамилияСотрудникаDataGridViewTextBoxColumn";
            // 
            // имяСотрудникаDataGridViewTextBoxColumn
            // 
            this.имяСотрудникаDataGridViewTextBoxColumn.DataPropertyName = "Имя сотрудника";
            this.имяСотрудникаDataGridViewTextBoxColumn.HeaderText = "Имя сотрудника";
            this.имяСотрудникаDataGridViewTextBoxColumn.Name = "имяСотрудникаDataGridViewTextBoxColumn";
            // 
            // oRGJoinBindingSource
            // 
            this.oRGJoinBindingSource.DataMember = "ORGJoin";
            this.oRGJoinBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // baseLPRDataSet
            // 
            this.baseLPRDataSet.DataSetName = "BaseLPRDataSet";
            this.baseLPRDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Город:";
            // 
            // tBCity
            // 
            this.tBCity.Location = new System.Drawing.Point(13, 45);
            this.tBCity.Name = "tBCity";
            this.tBCity.Size = new System.Drawing.Size(100, 20);
            this.tBCity.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(132, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Район города:";
            // 
            // tBCRaion
            // 
            this.tBCRaion.Location = new System.Drawing.Point(135, 45);
            this.tBCRaion.Name = "tBCRaion";
            this.tBCRaion.Size = new System.Drawing.Size(100, 20);
            this.tBCRaion.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(256, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Улица:";
            // 
            // tBCStreet
            // 
            this.tBCStreet.Location = new System.Drawing.Point(259, 45);
            this.tBCStreet.Name = "tBCStreet";
            this.tBCStreet.Size = new System.Drawing.Size(100, 20);
            this.tBCStreet.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(378, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Название огранизации";
            // 
            // cBORG
            // 
            this.cBORG.FormattingEnabled = true;
            this.cBORG.Location = new System.Drawing.Point(381, 43);
            this.cBORG.Name = "cBORG";
            this.cBORG.Size = new System.Drawing.Size(121, 21);
            this.cBORG.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(522, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "Статус:";
            // 
            // cBStatus
            // 
            this.cBStatus.FormattingEnabled = true;
            this.cBStatus.Items.AddRange(new object[] {
            "КП",
            "ПЕРЕГОВОРЫ",
            "СДЕЛКА",
            "ОТКАЗ"});
            this.cBStatus.Location = new System.Drawing.Point(525, 43);
            this.cBStatus.Name = "cBStatus";
            this.cBStatus.Size = new System.Drawing.Size(121, 21);
            this.cBStatus.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(649, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Сотрудник ИМЯ:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(777, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 13);
            this.label7.TabIndex = 14;
            this.label7.Text = "Сотрудник Фамилия:";
            // 
            // bFilter
            // 
            this.bFilter.Location = new System.Drawing.Point(930, 40);
            this.bFilter.Name = "bFilter";
            this.bFilter.Size = new System.Drawing.Size(75, 23);
            this.bFilter.TabIndex = 16;
            this.bFilter.Text = "Фильтр";
            this.bFilter.UseVisualStyleBackColor = true;
            this.bFilter.Click += new System.EventHandler(this.bFilter_Click);
            // 
            // oRGJoinTableAdapter
            // 
            this.oRGJoinTableAdapter.ClearBeforeFill = true;
            // 
            // cBNameSotr
            // 
            this.cBNameSotr.FormattingEnabled = true;
            this.cBNameSotr.Location = new System.Drawing.Point(652, 43);
            this.cBNameSotr.Name = "cBNameSotr";
            this.cBNameSotr.Size = new System.Drawing.Size(121, 21);
            this.cBNameSotr.TabIndex = 17;
            // 
            // cBFamSotr
            // 
            this.cBFamSotr.FormattingEnabled = true;
            this.cBFamSotr.Location = new System.Drawing.Point(780, 43);
            this.cBFamSotr.Name = "cBFamSotr";
            this.cBFamSotr.Size = new System.Drawing.Size(121, 21);
            this.cBFamSotr.TabIndex = 18;
            // 
            // FUserG
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1171, 582);
            this.Controls.Add(this.cBFamSotr);
            this.Controls.Add(this.cBNameSotr);
            this.Controls.Add(this.bFilter);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cBStatus);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cBORG);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tBCStreet);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.tBCRaion);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tBCity);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FUserG";
            this.Text = "Форма пользователя";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oRGJoinBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseLPRDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem правкаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавитьРайонГородаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавитьУлицуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавитьДомToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавитьОрганизациюToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчетыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem формированиеОтчетаПоГородуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem формированиеОтчетаПоРайонуГородаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem формированиеОтчетаПоОрганизацииToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tBCity;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tBCRaion;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tBCStreet;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cBORG;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cBStatus;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button bFilter;
        private System.Windows.Forms.DataGridViewTextBoxColumn информацияОЛПРDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource oRGJoinBindingSource;
        private BaseLPRDataSet baseLPRDataSet;
        private BaseLPRDataSetTableAdapters.ORGJoinTableAdapter oRGJoinTableAdapter;
        private System.Windows.Forms.ComboBox cBNameSotr;
        private System.Windows.Forms.ComboBox cBFamSotr;
        private System.Windows.Forms.DataGridViewTextBoxColumn фамилияИмяСотрудникаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn сотрудникОрганизацииИКонтактыDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеОрганизацииDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn статусDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn описаниеDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn фАМИЛИЯЛПРDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn иМЯЛПРDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn почтаЛПРDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn нормерТелЛПРDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn областьDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn районОбластиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn населенныйПунктDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеРнаГородаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn улицаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерДомаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn технологияПредосталенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn технологияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn почтаОрганизацииDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерТелефонаОргDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn фамилияСотрудникаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn имяСотрудникаDataGridViewTextBoxColumn;
    }
}