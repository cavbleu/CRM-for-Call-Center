﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;

namespace CRM_for_CALL_Center
{
    public partial class FOrg : Form
    {

        BaseLPRDataSetTableAdapters.QueriesTableAdapter queriesTAdap;
        public FOrg()
        {
            InitializeComponent();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.oRGJoinTableAdapter.Fill(this.baseLPRDataSet.ORGJoin,"","","","","","","");
        }

        private void buttonADD_Click(object sender, EventArgs e)
        {
            queriesTAdap = new BaseLPRDataSetTableAdapters.QueriesTableAdapter();
            if (tBIDaddORG.Text == "" || tBNameaddORG.Text == "" || tBINNaddORG.Name == "" || tBOGRNaddORG.Text == ""
                || cBCityAddORG.Text == "" || cBRCAdd.Text == "" || cBStreetAddORG.Text == "" ||
                cBnumBildADDoRG.Text == "" || tBIDLPRAdd.Text == "" || tBFamLPRADD.Text == "" ||
                tBOtchLPRADD.Text == "" || tBMailLPRADD.Text == ""
                || tBMailADDORG.Text == "" || cBStatusADD.Text == "" ||
                cBFamSotrADD.Text == "" || cBNameSotrADD.Text == "" || cBOtchSotrADD.Text == "" ||
                tBDescADD.Text == "")
            { MessageBox.Show("Не введен параметр!"); }
            else
            {
                //try
                //{
                    queriesTAdap.AddOrg(Convert.ToInt32(tBIDaddORG.Text.ToString()), 
                        tBNameaddORG.Text,
                        Convert.ToInt32(tBINNaddORG.Text.ToString()), 
                        Convert.ToInt32(tBOGRNaddORG.Text.ToString()), 
                        cBCityAddORG.Text, 
                        cBRCAdd.Text, 
                        cBStreetAddORG.Text, 
                        cBnumBildADDoRG.Text, 
                        Convert.ToInt32(tBIDLPRAdd.Text.ToString()), 
                        cBStatusADD.Text,
                        tBDescADD.Text, 
                        tBFamLPRADD.Text, 
                        tBNameLPRADD.Text,
                        tBOtchLPRADD.Text,
                        tBMailLPRADD.Text, 
                        Convert.ToInt32(tBnumtelLPRADD.Text.ToString()),
                        tBMailLPRADD.Text,
                        Convert.ToInt32(tBnumtelORGADD.Text.ToString()),
                        cBNameSotrADD.Text,
                        cBOtchSotrADD.Text,
                        cBFamSotrADD.Text);
                    this.oRGTableAdapter.Adapter.Update(this.baseLPRDataSet.ORG);
                    this.oRGMenTableAdapter.Adapter.Update(this.baseLPRDataSet.ORGMen);
                    this.oRGJoinTableAdapter.Adapter.Update(this.baseLPRDataSet.ORGJoin);
                    this.oRGJoinTableAdapter.Fill(this.baseLPRDataSet.ORGJoin, "", "", "", "", "", "", "");
                if (cBAddmail.Checked == true)
                {
                    const string mailfrom = "dmitryzav@yandex.ru";
                    const String FROM = mailfrom;
                    string mailFROMNAME = $"'{tBNameaddORG.Text}' дата '{dateTimePicker1.Text.ToString()}'";
                    String FROMNAME = mailFROMNAME;
                    
                    String TO = $"'{cBSotrMailAdd.Text.ToString()}'";
                    
                    const String SMTP_USERNAME = "dmitryzav@yandex.ru";
                    
                    const String SMTP_PASSWORD = "dog591461122";
                    
                    
                    const String HOST = "smtp.yandex.ru";
                    
                    const int PORT = 25;

                    String SUBJECT = mailFROMNAME;
                   String BODY =
                        $"'{tBNameaddORG.Text}' '{cBStatusADD.Text}' '{tBDescADD.Text}' '{tBFamLPRADD.Text}' '{tBNameaddORG.Text}' '{tBOtchLPRADD.Text}' '{tBnumtelLPRADD.Text}' номер лпр; '{tBnumtelORGADD.Text}'; '{tBMailLPRADD.Text}' почта лпр; '{tBMailADDORG.Text}'; '{cBCityAddORG.Text}'-'{cBStreetAddORG.Text}'-'{cBnumBildADDoRG.Text}'";
                    
                    

                    
                    MailMessage message = new MailMessage();
                    message.IsBodyHtml = true;
                    message.From = new MailAddress(FROM, FROMNAME);
                    message.To.Add(new MailAddress(TO));
                    message.Subject = SUBJECT;

                    // Create and configure a new SmtpClient
                    SmtpClient client =
                        new SmtpClient(HOST, PORT);
                    // Pass SMTP credentials
                    client.Credentials =
                        new NetworkCredential(SMTP_USERNAME, SMTP_PASSWORD);
                    // Enable SSL encryption
                    client.EnableSsl = true;

                    // Send the email. 
                    try
                    {
                        //Console.WriteLine("Attempting to send email...");
                        client.Send(message);
                        MessageBox.Show("Email отправлено!");
                    }
                    catch (Exception ex)
                    {
                        //Console.WriteLine("The email was not sent.");
                        MessageBox.Show("Ошибка отправки Email: " + ex.Message);
                    }
                    
                
            }
                    tBIDaddORG.Clear();
                    tBNameaddORG.Clear();
                    tBINNaddORG.Clear();
                    tBOGRNaddORG.Clear();
                    tBIDLPRAdd.Clear();
                    tBFamLPRADD.Clear();
                    tBNameLPRADD.Clear();
                    tBOtchLPRADD.Clear();
                    tBMailLPRADD.Clear();
                    tBnumtelLPRADD.Clear();
                    tBMailLPRADD.Clear();
                    tBDescADD.Clear();
                    
                //}
                //catch { MessageBox.Show("Данные не добавлены!"); }
            }
        }

        private void FOrg_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.Sotryd". При необходимости она может быть перемещена или удалена.
            this.sotrydTableAdapter.Fill(this.baseLPRDataSet.Sotryd);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.ORGMen". При необходимости она может быть перемещена или удалена.
            this.oRGMenTableAdapter.Fill(this.baseLPRDataSet.ORGMen);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.ORG". При необходимости она может быть перемещена или удалена.
            this.oRGTableAdapter.Fill(this.baseLPRDataSet.ORG);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.Sotryd". При необходимости она может быть перемещена или удалена.
            this.sotrydTableAdapter.Fill(this.baseLPRDataSet.Sotryd);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.Bilding". При необходимости она может быть перемещена или удалена.
            this.bildingTableAdapter.Fill(this.baseLPRDataSet.Bilding);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.Street". При необходимости она может быть перемещена или удалена.
            this.streetTableAdapter.Fill(this.baseLPRDataSet.Street);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.Raion". При необходимости она может быть перемещена или удалена.
            this.raionTableAdapter.Fill(this.baseLPRDataSet.Raion);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.City". При необходимости она может быть перемещена или удалена.
            this.cityTableAdapter.Fill(this.baseLPRDataSet.City);

        }

        private void butUPD_Click(object sender, EventArgs e)
        {
            queriesTAdap = new BaseLPRDataSetTableAdapters.QueriesTableAdapter();
            if (cBNameORGUPD.Text == "" || tBinnUPD.Text == "" || 
                tBogrnUPD.Text == "" || cBCityUPD.Text == ""
                || cBStreetUPD.Text == "" || cBnumBildUPD.Text == "" || 
                tBNameLPRUPG.Text == "" || cBRaionUPD.Text == ""||
                tBFamLPRUPD.Text == "" || tBOtchLPRUPD.Text == "" || 
                tBMailORGUPD.Text == "" ||
                tBnumtelORGUPD.Text == "" || cBStatusUPD.Text == ""
                || cBSotrFamUPD.Text == "" || cBNameSotrUPD.Text == "" ||
                cBSotrOtchUPD.Text == "" || tBDescORGUPD.Text == "")
            { MessageBox.Show("Не введен параметр!"); }
            else
            {
                try
                {
                    queriesTAdap.UPDOrg(cBNameORGUPD.Text, Convert.ToInt32(tBinnUPD.Text), Convert.ToInt32(tBogrnUPD.Text),
                        cBCityUPD.Text, cBRaionUPD.Text, cBStreetUPD.Text, cBnumBildUPD.Text,
                        tBMailORGUPD.Text, Convert.ToInt32(tBnumtelORGUPD.Text),cBSotrFamUPD.Text,cBNameSotrUPD.Text,
                        cBSotrOtchUPD.Text
                        );
                    queriesTAdap.UPDOrgMen(cBNameORGUPD.Text, cBStatusUPD.Text,tBDescORGUPD.Text,
                        tBFamLPRUPD.Text,tBNameLPRUPG.Text,tBOtchLPRUPD.Text);
                    this.oRGTableAdapter.Adapter.Update(this.baseLPRDataSet.ORG);
                    this.oRGMenTableAdapter.Adapter.Update(this.baseLPRDataSet.ORGMen);
                    this.oRGJoinTableAdapter.Adapter.Update(this.baseLPRDataSet.ORGJoin);
                    this.oRGJoinTableAdapter.Fill(this.baseLPRDataSet.ORGJoin, "", "", "", "", "", "", "");
                    tBinnUPD.Clear();
                    tBogrnUPD.Clear();
                    tBNameLPRUPG.Clear();
                    tBFamLPRUPD.Clear();
                    tBOtchLPRUPD.Clear();
                    tBMailORGUPD.Clear();
                    tBnumtelORGUPD.Clear();
                    tBDescORGUPD.Clear();
                }
                catch { MessageBox.Show("Данные не изменены!"); }
            }
        }

        private void butDel_Click(object sender, EventArgs e)
        {
            queriesTAdap = new BaseLPRDataSetTableAdapters.QueriesTableAdapter();
            if (cBNameORGDEL.Text==""||cBFamLPRDEL.Text==""||cBOtchLPRDEL.Text==""||cBNameORGDEL.Text=="")
            { MessageBox.Show("Не введен параметр!"); }
            else
            {
                try
                {
                    queriesTAdap.delorgMen(cBNameORGDEL.Text,cBFamLPRDEL.Text,cBNameORGDEL.Text,cBOtchLPRDEL.Text);
                     this.oRGTableAdapter.Adapter.Update(this.baseLPRDataSet.ORG);
                    this.oRGMenTableAdapter.Adapter.Update(this.baseLPRDataSet.ORGMen);
                    this.oRGJoinTableAdapter.Adapter.Update(this.baseLPRDataSet.ORGJoin);
                    this.oRGJoinTableAdapter.Fill(this.baseLPRDataSet.ORGJoin, "", "", "", "", "", "", "");
                }
                catch { MessageBox.Show("Данные не удалены!"); }
            }
        }
    }
}
