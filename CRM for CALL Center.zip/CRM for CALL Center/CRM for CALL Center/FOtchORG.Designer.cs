﻿namespace CRM_for_CALL_Center
{
    partial class FOtchORG
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.cBStatus = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cBORG = new System.Windows.Forms.ComboBox();
            this.oRGBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.baseLPRDataSet = new CRM_for_CALL_Center.BaseLPRDataSet();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.butSearch = new System.Windows.Forms.Button();
            this.butForm = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.oRGJoinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cBCity = new System.Windows.Forms.ComboBox();
            this.cityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cBRCity = new System.Windows.Forms.ComboBox();
            this.fKRaionCityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cBStreet = new System.Windows.Forms.ComboBox();
            this.fKStreetRaionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cBSotrN = new System.Windows.Forms.ComboBox();
            this.sotrydBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cBSotrF = new System.Windows.Forms.ComboBox();
            this.oRGJoinTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.ORGJoinTableAdapter();
            this.cityTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.CityTableAdapter();
            this.raionTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.RaionTableAdapter();
            this.streetTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.StreetTableAdapter();
            this.oRGTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.ORGTableAdapter();
            this.sotrydTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.SotrydTableAdapter();
            this.названиеОрганизацииDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.статусDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.описаниеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фАМИЛИЯЛПРDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.иМЯЛПРDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.почтаЛПРDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.нормерТелЛПРDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.областьDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.районОбластиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.населенныйПунктDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеРнаГородаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.улицаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерДомаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.технологияПредосталенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.технологияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.почтаОрганизацииDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерТелефонаОргDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фамилияСотрудникаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.имяСотрудникаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.oRGBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseLPRDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oRGJoinBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKRaionCityBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKStreetRaionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrydBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(135, 57);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(115, 13);
            this.label7.TabIndex = 28;
            this.label7.Text = "Сотрудник Фамилия:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(91, 13);
            this.label6.TabIndex = 26;
            this.label6.Text = "Сотрудник ИМЯ:";
            // 
            // cBStatus
            // 
            this.cBStatus.FormattingEnabled = true;
            this.cBStatus.Items.AddRange(new object[] {
            "КП",
            "ПЕРЕГОВОРЫ",
            "ОТКАЗ",
            "СДЕЛКА"});
            this.cBStatus.Location = new System.Drawing.Point(523, 26);
            this.cBStatus.Name = "cBStatus";
            this.cBStatus.Size = new System.Drawing.Size(121, 21);
            this.cBStatus.TabIndex = 25;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(524, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 24;
            this.label5.Text = "Статус:";
            // 
            // cBORG
            // 
            this.cBORG.DataSource = this.oRGBindingSource;
            this.cBORG.DisplayMember = "name";
            this.cBORG.FormattingEnabled = true;
            this.cBORG.Location = new System.Drawing.Point(396, 26);
            this.cBORG.Name = "cBORG";
            this.cBORG.Size = new System.Drawing.Size(121, 21);
            this.cBORG.TabIndex = 23;
            // 
            // oRGBindingSource
            // 
            this.oRGBindingSource.DataMember = "ORG";
            this.oRGBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // baseLPRDataSet
            // 
            this.baseLPRDataSet.DataSetName = "BaseLPRDataSet";
            this.baseLPRDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(393, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(125, 13);
            this.label4.TabIndex = 22;
            this.label4.Text = "Название огранизации";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(263, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "Улица:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(135, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Район города:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "Город:";
            // 
            // butSearch
            // 
            this.butSearch.Location = new System.Drawing.Point(273, 71);
            this.butSearch.Name = "butSearch";
            this.butSearch.Size = new System.Drawing.Size(75, 23);
            this.butSearch.TabIndex = 30;
            this.butSearch.Text = "Поиск";
            this.butSearch.UseVisualStyleBackColor = true;
            this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
            // 
            // butForm
            // 
            this.butForm.Location = new System.Drawing.Point(370, 71);
            this.butForm.Name = "butForm";
            this.butForm.Size = new System.Drawing.Size(106, 23);
            this.butForm.TabIndex = 31;
            this.butForm.Text = "Сформировать";
            this.butForm.UseVisualStyleBackColor = true;
            this.butForm.Click += new System.EventHandler(this.butForm_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.названиеОрганизацииDataGridViewTextBoxColumn,
            this.статусDataGridViewTextBoxColumn,
            this.описаниеDataGridViewTextBoxColumn,
            this.фАМИЛИЯЛПРDataGridViewTextBoxColumn,
            this.иМЯЛПРDataGridViewTextBoxColumn,
            this.почтаЛПРDataGridViewTextBoxColumn,
            this.нормерТелЛПРDataGridViewTextBoxColumn,
            this.областьDataGridViewTextBoxColumn,
            this.районОбластиDataGridViewTextBoxColumn,
            this.населенныйПунктDataGridViewTextBoxColumn,
            this.названиеРнаГородаDataGridViewTextBoxColumn,
            this.улицаDataGridViewTextBoxColumn,
            this.номерДомаDataGridViewTextBoxColumn,
            this.технологияПредосталенияDataGridViewTextBoxColumn,
            this.технологияDataGridViewTextBoxColumn,
            this.почтаОрганизацииDataGridViewTextBoxColumn,
            this.номерТелефонаОргDataGridViewTextBoxColumn,
            this.фамилияСотрудникаDataGridViewTextBoxColumn,
            this.имяСотрудникаDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.oRGJoinBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(7, 103);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(828, 361);
            this.dataGridView1.TabIndex = 32;
            // 
            // oRGJoinBindingSource
            // 
            this.oRGJoinBindingSource.DataMember = "ORGJoin";
            this.oRGJoinBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // cBCity
            // 
            this.cBCity.DataSource = this.cityBindingSource;
            this.cBCity.DisplayMember = "Name";
            this.cBCity.FormattingEnabled = true;
            this.cBCity.Location = new System.Drawing.Point(10, 26);
            this.cBCity.Name = "cBCity";
            this.cBCity.Size = new System.Drawing.Size(121, 21);
            this.cBCity.TabIndex = 33;
            this.cBCity.ValueMember = "idCity";
            // 
            // cityBindingSource
            // 
            this.cityBindingSource.DataMember = "City";
            this.cityBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // cBRCity
            // 
            this.cBRCity.DataSource = this.fKRaionCityBindingSource;
            this.cBRCity.DisplayMember = "NameR";
            this.cBRCity.FormattingEnabled = true;
            this.cBRCity.Location = new System.Drawing.Point(138, 25);
            this.cBRCity.Name = "cBRCity";
            this.cBRCity.Size = new System.Drawing.Size(121, 21);
            this.cBRCity.TabIndex = 34;
            this.cBRCity.ValueMember = "idRaion";
            // 
            // fKRaionCityBindingSource
            // 
            this.fKRaionCityBindingSource.DataMember = "FK_Raion_City";
            this.fKRaionCityBindingSource.DataSource = this.cityBindingSource;
            // 
            // cBStreet
            // 
            this.cBStreet.DataSource = this.fKStreetRaionBindingSource;
            this.cBStreet.DisplayMember = "NameS";
            this.cBStreet.FormattingEnabled = true;
            this.cBStreet.Location = new System.Drawing.Point(266, 25);
            this.cBStreet.Name = "cBStreet";
            this.cBStreet.Size = new System.Drawing.Size(121, 21);
            this.cBStreet.TabIndex = 35;
            this.cBStreet.ValueMember = "idStreet";
            // 
            // fKStreetRaionBindingSource
            // 
            this.fKStreetRaionBindingSource.DataMember = "FK_Street_Raion";
            this.fKStreetRaionBindingSource.DataSource = this.fKRaionCityBindingSource;
            // 
            // cBSotrN
            // 
            this.cBSotrN.DataSource = this.sotrydBindingSource;
            this.cBSotrN.DisplayMember = "Name";
            this.cBSotrN.FormattingEnabled = true;
            this.cBSotrN.Location = new System.Drawing.Point(10, 73);
            this.cBSotrN.Name = "cBSotrN";
            this.cBSotrN.Size = new System.Drawing.Size(121, 21);
            this.cBSotrN.TabIndex = 36;
            this.cBSotrN.ValueMember = "ID";
            // 
            // sotrydBindingSource
            // 
            this.sotrydBindingSource.DataMember = "Sotryd";
            this.sotrydBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // cBSotrF
            // 
            this.cBSotrF.DataSource = this.sotrydBindingSource;
            this.cBSotrF.DisplayMember = "Fam";
            this.cBSotrF.FormattingEnabled = true;
            this.cBSotrF.Location = new System.Drawing.Point(138, 73);
            this.cBSotrF.Name = "cBSotrF";
            this.cBSotrF.Size = new System.Drawing.Size(121, 21);
            this.cBSotrF.TabIndex = 37;
            this.cBSotrF.ValueMember = "ID";
            // 
            // oRGJoinTableAdapter
            // 
            this.oRGJoinTableAdapter.ClearBeforeFill = true;
            // 
            // cityTableAdapter
            // 
            this.cityTableAdapter.ClearBeforeFill = true;
            // 
            // raionTableAdapter
            // 
            this.raionTableAdapter.ClearBeforeFill = true;
            // 
            // streetTableAdapter
            // 
            this.streetTableAdapter.ClearBeforeFill = true;
            // 
            // oRGTableAdapter
            // 
            this.oRGTableAdapter.ClearBeforeFill = true;
            // 
            // sotrydTableAdapter
            // 
            this.sotrydTableAdapter.ClearBeforeFill = true;
            // 
            // названиеОрганизацииDataGridViewTextBoxColumn
            // 
            this.названиеОрганизацииDataGridViewTextBoxColumn.DataPropertyName = "Название организации";
            this.названиеОрганизацииDataGridViewTextBoxColumn.HeaderText = "Название организации";
            this.названиеОрганизацииDataGridViewTextBoxColumn.Name = "названиеОрганизацииDataGridViewTextBoxColumn";
            // 
            // статусDataGridViewTextBoxColumn
            // 
            this.статусDataGridViewTextBoxColumn.DataPropertyName = "Статус";
            this.статусDataGridViewTextBoxColumn.HeaderText = "Статус";
            this.статусDataGridViewTextBoxColumn.Name = "статусDataGridViewTextBoxColumn";
            // 
            // описаниеDataGridViewTextBoxColumn
            // 
            this.описаниеDataGridViewTextBoxColumn.DataPropertyName = "Описание";
            this.описаниеDataGridViewTextBoxColumn.HeaderText = "Описание";
            this.описаниеDataGridViewTextBoxColumn.Name = "описаниеDataGridViewTextBoxColumn";
            // 
            // фАМИЛИЯЛПРDataGridViewTextBoxColumn
            // 
            this.фАМИЛИЯЛПРDataGridViewTextBoxColumn.DataPropertyName = "ФАМИЛИЯ ЛПР";
            this.фАМИЛИЯЛПРDataGridViewTextBoxColumn.HeaderText = "ФАМИЛИЯ ЛПР";
            this.фАМИЛИЯЛПРDataGridViewTextBoxColumn.Name = "фАМИЛИЯЛПРDataGridViewTextBoxColumn";
            // 
            // иМЯЛПРDataGridViewTextBoxColumn
            // 
            this.иМЯЛПРDataGridViewTextBoxColumn.DataPropertyName = "ИМЯ ЛПР";
            this.иМЯЛПРDataGridViewTextBoxColumn.HeaderText = "ИМЯ ЛПР";
            this.иМЯЛПРDataGridViewTextBoxColumn.Name = "иМЯЛПРDataGridViewTextBoxColumn";
            // 
            // почтаЛПРDataGridViewTextBoxColumn
            // 
            this.почтаЛПРDataGridViewTextBoxColumn.DataPropertyName = "Почта ЛПР";
            this.почтаЛПРDataGridViewTextBoxColumn.HeaderText = "Почта ЛПР";
            this.почтаЛПРDataGridViewTextBoxColumn.Name = "почтаЛПРDataGridViewTextBoxColumn";
            // 
            // нормерТелЛПРDataGridViewTextBoxColumn
            // 
            this.нормерТелЛПРDataGridViewTextBoxColumn.DataPropertyName = "Нормер тел ЛПР";
            this.нормерТелЛПРDataGridViewTextBoxColumn.HeaderText = "Нормер тел ЛПР";
            this.нормерТелЛПРDataGridViewTextBoxColumn.Name = "нормерТелЛПРDataGridViewTextBoxColumn";
            // 
            // областьDataGridViewTextBoxColumn
            // 
            this.областьDataGridViewTextBoxColumn.DataPropertyName = "Область";
            this.областьDataGridViewTextBoxColumn.HeaderText = "Область";
            this.областьDataGridViewTextBoxColumn.Name = "областьDataGridViewTextBoxColumn";
            // 
            // районОбластиDataGridViewTextBoxColumn
            // 
            this.районОбластиDataGridViewTextBoxColumn.DataPropertyName = "Район области";
            this.районОбластиDataGridViewTextBoxColumn.HeaderText = "Район области";
            this.районОбластиDataGridViewTextBoxColumn.Name = "районОбластиDataGridViewTextBoxColumn";
            // 
            // населенныйПунктDataGridViewTextBoxColumn
            // 
            this.населенныйПунктDataGridViewTextBoxColumn.DataPropertyName = "Населенный пункт";
            this.населенныйПунктDataGridViewTextBoxColumn.HeaderText = "Населенный пункт";
            this.населенныйПунктDataGridViewTextBoxColumn.Name = "населенныйПунктDataGridViewTextBoxColumn";
            // 
            // названиеРнаГородаDataGridViewTextBoxColumn
            // 
            this.названиеРнаГородаDataGridViewTextBoxColumn.DataPropertyName = "Название р-на города";
            this.названиеРнаГородаDataGridViewTextBoxColumn.HeaderText = "Название р-на города";
            this.названиеРнаГородаDataGridViewTextBoxColumn.Name = "названиеРнаГородаDataGridViewTextBoxColumn";
            // 
            // улицаDataGridViewTextBoxColumn
            // 
            this.улицаDataGridViewTextBoxColumn.DataPropertyName = "Улица";
            this.улицаDataGridViewTextBoxColumn.HeaderText = "Улица";
            this.улицаDataGridViewTextBoxColumn.Name = "улицаDataGridViewTextBoxColumn";
            // 
            // номерДомаDataGridViewTextBoxColumn
            // 
            this.номерДомаDataGridViewTextBoxColumn.DataPropertyName = "Номер дома";
            this.номерДомаDataGridViewTextBoxColumn.HeaderText = "Номер дома";
            this.номерДомаDataGridViewTextBoxColumn.Name = "номерДомаDataGridViewTextBoxColumn";
            // 
            // технологияПредосталенияDataGridViewTextBoxColumn
            // 
            this.технологияПредосталенияDataGridViewTextBoxColumn.DataPropertyName = "Технология предосталения";
            this.технологияПредосталенияDataGridViewTextBoxColumn.HeaderText = "Технология предосталения";
            this.технологияПредосталенияDataGridViewTextBoxColumn.Name = "технологияПредосталенияDataGridViewTextBoxColumn";
            // 
            // технологияDataGridViewTextBoxColumn
            // 
            this.технологияDataGridViewTextBoxColumn.DataPropertyName = "Технология";
            this.технологияDataGridViewTextBoxColumn.HeaderText = "Технология";
            this.технологияDataGridViewTextBoxColumn.Name = "технологияDataGridViewTextBoxColumn";
            // 
            // почтаОрганизацииDataGridViewTextBoxColumn
            // 
            this.почтаОрганизацииDataGridViewTextBoxColumn.DataPropertyName = "Почта организации";
            this.почтаОрганизацииDataGridViewTextBoxColumn.HeaderText = "Почта организации";
            this.почтаОрганизацииDataGridViewTextBoxColumn.Name = "почтаОрганизацииDataGridViewTextBoxColumn";
            // 
            // номерТелефонаОргDataGridViewTextBoxColumn
            // 
            this.номерТелефонаОргDataGridViewTextBoxColumn.DataPropertyName = "Номер телефона орг";
            this.номерТелефонаОргDataGridViewTextBoxColumn.HeaderText = "Номер телефона орг";
            this.номерТелефонаОргDataGridViewTextBoxColumn.Name = "номерТелефонаОргDataGridViewTextBoxColumn";
            // 
            // фамилияСотрудникаDataGridViewTextBoxColumn
            // 
            this.фамилияСотрудникаDataGridViewTextBoxColumn.DataPropertyName = "Фамилия сотрудника";
            this.фамилияСотрудникаDataGridViewTextBoxColumn.HeaderText = "Фамилия сотрудника";
            this.фамилияСотрудникаDataGridViewTextBoxColumn.Name = "фамилияСотрудникаDataGridViewTextBoxColumn";
            // 
            // имяСотрудникаDataGridViewTextBoxColumn
            // 
            this.имяСотрудникаDataGridViewTextBoxColumn.DataPropertyName = "Имя сотрудника";
            this.имяСотрудникаDataGridViewTextBoxColumn.HeaderText = "Имя сотрудника";
            this.имяСотрудникаDataGridViewTextBoxColumn.Name = "имяСотрудникаDataGridViewTextBoxColumn";
            // 
            // FOtchORG
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(847, 476);
            this.Controls.Add(this.cBSotrF);
            this.Controls.Add(this.cBSotrN);
            this.Controls.Add(this.cBStreet);
            this.Controls.Add(this.cBRCity);
            this.Controls.Add(this.cBCity);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.butForm);
            this.Controls.Add(this.butSearch);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cBStatus);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cBORG);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FOtchORG";
            this.Text = "Отчет по организациям";
            this.Load += new System.EventHandler(this.FOtchORG_Load);
            ((System.ComponentModel.ISupportInitialize)(this.oRGBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseLPRDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oRGJoinBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKRaionCityBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKStreetRaionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrydBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cBStatus;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cBORG;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button butSearch;
        private System.Windows.Forms.Button butForm;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox cBCity;
        private System.Windows.Forms.ComboBox cBRCity;
        private System.Windows.Forms.ComboBox cBStreet;
        private System.Windows.Forms.ComboBox cBSotrN;
        private System.Windows.Forms.ComboBox cBSotrF;
        private System.Windows.Forms.DataGridViewTextBoxColumn фамилияИмяСотрудникаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn сотрудникОрганизацииИКонтактыDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn информацияОЛПРDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource oRGJoinBindingSource;
        private BaseLPRDataSet baseLPRDataSet;
        private BaseLPRDataSetTableAdapters.ORGJoinTableAdapter oRGJoinTableAdapter;
        private System.Windows.Forms.BindingSource cityBindingSource;
        private BaseLPRDataSetTableAdapters.CityTableAdapter cityTableAdapter;
        private System.Windows.Forms.BindingSource fKRaionCityBindingSource;
        private BaseLPRDataSetTableAdapters.RaionTableAdapter raionTableAdapter;
        private System.Windows.Forms.BindingSource fKStreetRaionBindingSource;
        private BaseLPRDataSetTableAdapters.StreetTableAdapter streetTableAdapter;
        private System.Windows.Forms.BindingSource oRGBindingSource;
        private BaseLPRDataSetTableAdapters.ORGTableAdapter oRGTableAdapter;
        private System.Windows.Forms.BindingSource sotrydBindingSource;
        private BaseLPRDataSetTableAdapters.SotrydTableAdapter sotrydTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеОрганизацииDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn статусDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn описаниеDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn фАМИЛИЯЛПРDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn иМЯЛПРDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn почтаЛПРDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn нормерТелЛПРDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn областьDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn районОбластиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn населенныйПунктDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеРнаГородаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn улицаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерДомаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn технологияПредосталенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn технологияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn почтаОрганизацииDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерТелефонаОргDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn фамилияСотрудникаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn имяСотрудникаDataGridViewTextBoxColumn;
    }
}