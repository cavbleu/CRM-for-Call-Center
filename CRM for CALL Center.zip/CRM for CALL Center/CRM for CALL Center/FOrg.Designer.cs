﻿namespace CRM_for_CALL_Center
{
    partial class FOrg
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.cBSotrMailAdd = new System.Windows.Forms.ComboBox();
            this.sotrydBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.baseLPRDataSet = new CRM_for_CALL_Center.BaseLPRDataSet();
            this.cBAddmail = new System.Windows.Forms.CheckBox();
            this.label25 = new System.Windows.Forms.Label();
            this.cBRCAdd = new System.Windows.Forms.ComboBox();
            this.fKRaionCityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.buttonADD = new System.Windows.Forms.Button();
            this.cBOtchSotrADD = new System.Windows.Forms.ComboBox();
            this.cBNameSotrADD = new System.Windows.Forms.ComboBox();
            this.tBDescADD = new System.Windows.Forms.TextBox();
            this.cBFamSotrADD = new System.Windows.Forms.ComboBox();
            this.cBStatusADD = new System.Windows.Forms.ComboBox();
            this.tBnumtelORGADD = new System.Windows.Forms.TextBox();
            this.label59 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.tBMailADDORG = new System.Windows.Forms.TextBox();
            this.tBnumtelLPRADD = new System.Windows.Forms.TextBox();
            this.tBMailLPRADD = new System.Windows.Forms.TextBox();
            this.tBOtchLPRADD = new System.Windows.Forms.TextBox();
            this.tBNameLPRADD = new System.Windows.Forms.TextBox();
            this.tBFamLPRADD = new System.Windows.Forms.TextBox();
            this.tBIDLPRAdd = new System.Windows.Forms.TextBox();
            this.cBnumBildADDoRG = new System.Windows.Forms.ComboBox();
            this.fKBildingStreetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.fKStreetRaionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cBStreetAddORG = new System.Windows.Forms.ComboBox();
            this.cBCityAddORG = new System.Windows.Forms.ComboBox();
            this.tBOGRNaddORG = new System.Windows.Forms.TextBox();
            this.tBINNaddORG = new System.Windows.Forms.TextBox();
            this.tBNameaddORG = new System.Windows.Forms.TextBox();
            this.tBIDaddORG = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label14 = new System.Windows.Forms.Label();
            this.cBRaionUPD = new System.Windows.Forms.ComboBox();
            this.fKRaionCityBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.butUPD = new System.Windows.Forms.Button();
            this.cBSotrOtchUPD = new System.Windows.Forms.ComboBox();
            this.cBNameSotrUPD = new System.Windows.Forms.ComboBox();
            this.cBSotrFamUPD = new System.Windows.Forms.ComboBox();
            this.tBDescORGUPD = new System.Windows.Forms.TextBox();
            this.cBStatusUPD = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.tBnumtelORGUPD = new System.Windows.Forms.TextBox();
            this.tBMailORGUPD = new System.Windows.Forms.TextBox();
            this.tBOtchLPRUPD = new System.Windows.Forms.TextBox();
            this.tBNameLPRUPG = new System.Windows.Forms.TextBox();
            this.tBFamLPRUPD = new System.Windows.Forms.TextBox();
            this.cBnumBildUPD = new System.Windows.Forms.ComboBox();
            this.fKBildingStreetBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.fKStreetRaionBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.cBStreetUPD = new System.Windows.Forms.ComboBox();
            this.cBCityUPD = new System.Windows.Forms.ComboBox();
            this.tBogrnUPD = new System.Windows.Forms.TextBox();
            this.tBinnUPD = new System.Windows.Forms.TextBox();
            this.cBNameORGUPD = new System.Windows.Forms.ComboBox();
            this.oRGBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.butDel = new System.Windows.Forms.Button();
            this.cBOtchLPRDEL = new System.Windows.Forms.ComboBox();
            this.oRGMenBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cBNAmeLPRDEL = new System.Windows.Forms.ComboBox();
            this.cBFamLPRDEL = new System.Windows.Forms.ComboBox();
            this.cBNameORGDEL = new System.Windows.Forms.ComboBox();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.sotrydBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.названиеОрганизацииDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.статусDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.описаниеDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фАМИЛИЯЛПРDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.иМЯЛПРDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.почтаЛПРDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.нормерТелЛПРDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.областьDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.районОбластиDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.населенныйПунктDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеРнаГородаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.улицаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерДомаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.технологияПредосталенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.технологияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.почтаОрганизацииDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерТелефонаОргDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.фамилияСотрудникаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.имяСотрудникаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oRGJoinBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.oRGJoinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cityTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.CityTableAdapter();
            this.raionTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.RaionTableAdapter();
            this.streetTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.StreetTableAdapter();
            this.bildingTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.BildingTableAdapter();
            this.oRGTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.ORGTableAdapter();
            this.oRGMenTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.ORGMenTableAdapter();
            this.sotrydTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.SotrydTableAdapter();
            this.oRGJoinTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.ORGJoinTableAdapter();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sotrydBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseLPRDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKRaionCityBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKBildingStreetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKStreetRaionBindingSource)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fKRaionCityBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKBildingStreetBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKStreetRaionBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oRGBindingSource)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.oRGMenBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrydBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oRGJoinBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.oRGJoinBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(3, 4);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(966, 212);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.LightGray;
            this.tabPage1.Controls.Add(this.dateTimePicker1);
            this.tabPage1.Controls.Add(this.cBSotrMailAdd);
            this.tabPage1.Controls.Add(this.cBAddmail);
            this.tabPage1.Controls.Add(this.label25);
            this.tabPage1.Controls.Add(this.cBRCAdd);
            this.tabPage1.Controls.Add(this.buttonADD);
            this.tabPage1.Controls.Add(this.cBOtchSotrADD);
            this.tabPage1.Controls.Add(this.cBNameSotrADD);
            this.tabPage1.Controls.Add(this.tBDescADD);
            this.tabPage1.Controls.Add(this.cBFamSotrADD);
            this.tabPage1.Controls.Add(this.cBStatusADD);
            this.tabPage1.Controls.Add(this.tBnumtelORGADD);
            this.tabPage1.Controls.Add(this.label59);
            this.tabPage1.Controls.Add(this.label58);
            this.tabPage1.Controls.Add(this.tBMailADDORG);
            this.tabPage1.Controls.Add(this.tBnumtelLPRADD);
            this.tabPage1.Controls.Add(this.tBMailLPRADD);
            this.tabPage1.Controls.Add(this.tBOtchLPRADD);
            this.tabPage1.Controls.Add(this.tBNameLPRADD);
            this.tabPage1.Controls.Add(this.tBFamLPRADD);
            this.tabPage1.Controls.Add(this.tBIDLPRAdd);
            this.tabPage1.Controls.Add(this.cBnumBildADDoRG);
            this.tabPage1.Controls.Add(this.cBStreetAddORG);
            this.tabPage1.Controls.Add(this.cBCityAddORG);
            this.tabPage1.Controls.Add(this.tBOGRNaddORG);
            this.tabPage1.Controls.Add(this.tBINNaddORG);
            this.tabPage1.Controls.Add(this.tBNameaddORG);
            this.tabPage1.Controls.Add(this.tBIDaddORG);
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(958, 186);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Добавить:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Enabled = false;
            this.dateTimePicker1.Location = new System.Drawing.Point(733, 77);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 47;
            // 
            // cBSotrMailAdd
            // 
            this.cBSotrMailAdd.DataSource = this.sotrydBindingSource1;
            this.cBSotrMailAdd.DisplayMember = "mail";
            this.cBSotrMailAdd.Enabled = false;
            this.cBSotrMailAdd.FormattingEnabled = true;
            this.cBSotrMailAdd.Location = new System.Drawing.Point(733, 103);
            this.cBSotrMailAdd.Name = "cBSotrMailAdd";
            this.cBSotrMailAdd.Size = new System.Drawing.Size(200, 21);
            this.cBSotrMailAdd.TabIndex = 46;
            this.cBSotrMailAdd.ValueMember = "ID";
            // 
            // sotrydBindingSource1
            // 
            this.sotrydBindingSource1.DataMember = "Sotryd";
            this.sotrydBindingSource1.DataSource = this.baseLPRDataSet;
            // 
            // baseLPRDataSet
            // 
            this.baseLPRDataSet.DataSetName = "BaseLPRDataSet";
            this.baseLPRDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cBAddmail
            // 
            this.cBAddmail.AutoSize = true;
            this.cBAddmail.Location = new System.Drawing.Point(812, 130);
            this.cBAddmail.Name = "cBAddmail";
            this.cBAddmail.Size = new System.Drawing.Size(140, 17);
            this.cBAddmail.TabIndex = 45;
            this.cBAddmail.Text = "Отправить сообщение";
            this.cBAddmail.UseVisualStyleBackColor = true;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(569, 4);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(38, 13);
            this.label25.TabIndex = 44;
            this.label25.Text = "Район";
            // 
            // cBRCAdd
            // 
            this.cBRCAdd.DataSource = this.fKRaionCityBindingSource;
            this.cBRCAdd.DisplayMember = "NameR";
            this.cBRCAdd.FormattingEnabled = true;
            this.cBRCAdd.Location = new System.Drawing.Point(569, 22);
            this.cBRCAdd.Name = "cBRCAdd";
            this.cBRCAdd.Size = new System.Drawing.Size(121, 21);
            this.cBRCAdd.TabIndex = 43;
            this.cBRCAdd.ValueMember = "idRaion";
            // 
            // fKRaionCityBindingSource
            // 
            this.fKRaionCityBindingSource.DataMember = "FK_Raion_City";
            this.fKRaionCityBindingSource.DataSource = this.cityBindingSource;
            // 
            // cityBindingSource
            // 
            this.cityBindingSource.DataMember = "City";
            this.cityBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // buttonADD
            // 
            this.buttonADD.Location = new System.Drawing.Point(720, 130);
            this.buttonADD.Name = "buttonADD";
            this.buttonADD.Size = new System.Drawing.Size(75, 23);
            this.buttonADD.TabIndex = 42;
            this.buttonADD.Text = "Добавить";
            this.buttonADD.UseVisualStyleBackColor = true;
            this.buttonADD.Click += new System.EventHandler(this.buttonADD_Click);
            // 
            // cBOtchSotrADD
            // 
            this.cBOtchSotrADD.DataSource = this.sotrydBindingSource1;
            this.cBOtchSotrADD.DisplayMember = "Otch";
            this.cBOtchSotrADD.FormattingEnabled = true;
            this.cBOtchSotrADD.Location = new System.Drawing.Point(267, 159);
            this.cBOtchSotrADD.Name = "cBOtchSotrADD";
            this.cBOtchSotrADD.Size = new System.Drawing.Size(121, 21);
            this.cBOtchSotrADD.TabIndex = 41;
            this.cBOtchSotrADD.ValueMember = "ID";
            // 
            // cBNameSotrADD
            // 
            this.cBNameSotrADD.DataSource = this.sotrydBindingSource1;
            this.cBNameSotrADD.DisplayMember = "Name";
            this.cBNameSotrADD.FormattingEnabled = true;
            this.cBNameSotrADD.Location = new System.Drawing.Point(139, 159);
            this.cBNameSotrADD.Name = "cBNameSotrADD";
            this.cBNameSotrADD.Size = new System.Drawing.Size(121, 21);
            this.cBNameSotrADD.TabIndex = 40;
            this.cBNameSotrADD.ValueMember = "ID";
            // 
            // tBDescADD
            // 
            this.tBDescADD.Location = new System.Drawing.Point(440, 110);
            this.tBDescADD.Multiline = true;
            this.tBDescADD.Name = "tBDescADD";
            this.tBDescADD.Size = new System.Drawing.Size(250, 70);
            this.tBDescADD.TabIndex = 39;
            // 
            // cBFamSotrADD
            // 
            this.cBFamSotrADD.DataSource = this.sotrydBindingSource1;
            this.cBFamSotrADD.DisplayMember = "Fam";
            this.cBFamSotrADD.FormattingEnabled = true;
            this.cBFamSotrADD.Location = new System.Drawing.Point(10, 159);
            this.cBFamSotrADD.Name = "cBFamSotrADD";
            this.cBFamSotrADD.Size = new System.Drawing.Size(121, 21);
            this.cBFamSotrADD.TabIndex = 38;
            this.cBFamSotrADD.ValueMember = "ID";
            // 
            // cBStatusADD
            // 
            this.cBStatusADD.FormattingEnabled = true;
            this.cBStatusADD.Items.AddRange(new object[] {
            "КП",
            "ПЕРЕГОВОРЫ",
            "СДЕЛКА",
            "ОТКАЗ"});
            this.cBStatusADD.Location = new System.Drawing.Point(227, 110);
            this.cBStatusADD.Name = "cBStatusADD";
            this.cBStatusADD.Size = new System.Drawing.Size(121, 21);
            this.cBStatusADD.TabIndex = 37;
            // 
            // tBnumtelORGADD
            // 
            this.tBnumtelORGADD.Location = new System.Drawing.Point(121, 110);
            this.tBnumtelORGADD.Name = "tBnumtelORGADD";
            this.tBnumtelORGADD.Size = new System.Drawing.Size(100, 20);
            this.tBnumtelORGADD.TabIndex = 36;
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(442, 95);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(60, 13);
            this.label59.TabIndex = 35;
            this.label59.Text = "Описание:";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(227, 95);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(44, 13);
            this.label58.TabIndex = 34;
            this.label58.Text = "Статус:";
            // 
            // tBMailADDORG
            // 
            this.tBMailADDORG.Location = new System.Drawing.Point(10, 111);
            this.tBMailADDORG.Name = "tBMailADDORG";
            this.tBMailADDORG.Size = new System.Drawing.Size(100, 20);
            this.tBMailADDORG.TabIndex = 33;
            // 
            // tBnumtelLPRADD
            // 
            this.tBnumtelLPRADD.Location = new System.Drawing.Point(569, 67);
            this.tBnumtelLPRADD.Name = "tBnumtelLPRADD";
            this.tBnumtelLPRADD.Size = new System.Drawing.Size(100, 20);
            this.tBnumtelLPRADD.TabIndex = 32;
            // 
            // tBMailLPRADD
            // 
            this.tBMailLPRADD.Location = new System.Drawing.Point(441, 66);
            this.tBMailLPRADD.Name = "tBMailLPRADD";
            this.tBMailLPRADD.Size = new System.Drawing.Size(121, 20);
            this.tBMailLPRADD.TabIndex = 31;
            // 
            // tBOtchLPRADD
            // 
            this.tBOtchLPRADD.Location = new System.Drawing.Point(334, 66);
            this.tBOtchLPRADD.Name = "tBOtchLPRADD";
            this.tBOtchLPRADD.Size = new System.Drawing.Size(100, 20);
            this.tBOtchLPRADD.TabIndex = 29;
            // 
            // tBNameLPRADD
            // 
            this.tBNameLPRADD.Location = new System.Drawing.Point(227, 66);
            this.tBNameLPRADD.Name = "tBNameLPRADD";
            this.tBNameLPRADD.Size = new System.Drawing.Size(100, 20);
            this.tBNameLPRADD.TabIndex = 28;
            // 
            // tBFamLPRADD
            // 
            this.tBFamLPRADD.Location = new System.Drawing.Point(121, 66);
            this.tBFamLPRADD.Name = "tBFamLPRADD";
            this.tBFamLPRADD.Size = new System.Drawing.Size(100, 20);
            this.tBFamLPRADD.TabIndex = 27;
            // 
            // tBIDLPRAdd
            // 
            this.tBIDLPRAdd.Location = new System.Drawing.Point(10, 67);
            this.tBIDLPRAdd.Name = "tBIDLPRAdd";
            this.tBIDLPRAdd.Size = new System.Drawing.Size(100, 20);
            this.tBIDLPRAdd.TabIndex = 26;
            // 
            // cBnumBildADDoRG
            // 
            this.cBnumBildADDoRG.DataSource = this.fKBildingStreetBindingSource;
            this.cBnumBildADDoRG.DisplayMember = "number";
            this.cBnumBildADDoRG.FormattingEnabled = true;
            this.cBnumBildADDoRG.Location = new System.Drawing.Point(825, 23);
            this.cBnumBildADDoRG.Name = "cBnumBildADDoRG";
            this.cBnumBildADDoRG.Size = new System.Drawing.Size(121, 21);
            this.cBnumBildADDoRG.TabIndex = 25;
            // 
            // fKBildingStreetBindingSource
            // 
            this.fKBildingStreetBindingSource.DataMember = "FK_Bilding_Street";
            this.fKBildingStreetBindingSource.DataSource = this.fKStreetRaionBindingSource;
            // 
            // fKStreetRaionBindingSource
            // 
            this.fKStreetRaionBindingSource.DataMember = "FK_Street_Raion";
            this.fKStreetRaionBindingSource.DataSource = this.fKRaionCityBindingSource;
            // 
            // cBStreetAddORG
            // 
            this.cBStreetAddORG.DataSource = this.fKStreetRaionBindingSource;
            this.cBStreetAddORG.DisplayMember = "NameS";
            this.cBStreetAddORG.FormattingEnabled = true;
            this.cBStreetAddORG.Location = new System.Drawing.Point(697, 23);
            this.cBStreetAddORG.Name = "cBStreetAddORG";
            this.cBStreetAddORG.Size = new System.Drawing.Size(121, 21);
            this.cBStreetAddORG.TabIndex = 24;
            this.cBStreetAddORG.ValueMember = "idStreet";
            // 
            // cBCityAddORG
            // 
            this.cBCityAddORG.DataSource = this.cityBindingSource;
            this.cBCityAddORG.DisplayMember = "Name";
            this.cBCityAddORG.FormattingEnabled = true;
            this.cBCityAddORG.Location = new System.Drawing.Point(441, 22);
            this.cBCityAddORG.Name = "cBCityAddORG";
            this.cBCityAddORG.Size = new System.Drawing.Size(121, 21);
            this.cBCityAddORG.TabIndex = 23;
            this.cBCityAddORG.ValueMember = "idCity";
            // 
            // tBOGRNaddORG
            // 
            this.tBOGRNaddORG.Location = new System.Drawing.Point(334, 23);
            this.tBOGRNaddORG.Name = "tBOGRNaddORG";
            this.tBOGRNaddORG.Size = new System.Drawing.Size(100, 20);
            this.tBOGRNaddORG.TabIndex = 22;
            // 
            // tBINNaddORG
            // 
            this.tBINNaddORG.Location = new System.Drawing.Point(227, 23);
            this.tBINNaddORG.Name = "tBINNaddORG";
            this.tBINNaddORG.Size = new System.Drawing.Size(100, 20);
            this.tBINNaddORG.TabIndex = 21;
            // 
            // tBNameaddORG
            // 
            this.tBNameaddORG.Location = new System.Drawing.Point(121, 23);
            this.tBNameaddORG.Name = "tBNameaddORG";
            this.tBNameaddORG.Size = new System.Drawing.Size(100, 20);
            this.tBNameaddORG.TabIndex = 20;
            // 
            // tBIDaddORG
            // 
            this.tBIDaddORG.Location = new System.Drawing.Point(10, 24);
            this.tBIDaddORG.Name = "tBIDaddORG";
            this.tBIDaddORG.Size = new System.Drawing.Size(100, 20);
            this.tBIDaddORG.TabIndex = 19;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(264, 143);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(118, 13);
            this.label19.TabIndex = 18;
            this.label19.Text = "Отчество сотрудника:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(118, 95);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(88, 13);
            this.label18.TabIndex = 17;
            this.label18.Text = "Номер тел ОРГ:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(10, 95);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(64, 13);
            this.label17.TabIndex = 16;
            this.label17.Text = "Почта ОРГ:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(566, 46);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(90, 13);
            this.label16.TabIndex = 15;
            this.label16.Text = "Номер тел ЛПР:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(438, 50);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(66, 13);
            this.label15.TabIndex = 14;
            this.label15.Text = "Почта ЛПР:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(331, 50);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(83, 13);
            this.label13.TabIndex = 12;
            this.label13.Text = "Отчество ЛПР:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(224, 50);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 13);
            this.label12.TabIndex = 11;
            this.label12.Text = "Имя ЛПР:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(118, 50);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 13);
            this.label11.TabIndex = 10;
            this.label11.Text = "Фамилия ЛПР:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(10, 50);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(47, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "ID ЛПР:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(822, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Номер дома:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(694, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 13);
            this.label8.TabIndex = 7;
            this.label8.Text = "Улица:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(438, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(98, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Название города:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 145);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Фамилия сотрудника:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(136, 145);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Имя сотрудника:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(331, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(39, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "ОГРН:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(224, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "ИНН:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(118, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Название:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID:";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.cBRaionUPD);
            this.tabPage2.Controls.Add(this.butUPD);
            this.tabPage2.Controls.Add(this.cBSotrOtchUPD);
            this.tabPage2.Controls.Add(this.cBNameSotrUPD);
            this.tabPage2.Controls.Add(this.cBSotrFamUPD);
            this.tabPage2.Controls.Add(this.tBDescORGUPD);
            this.tabPage2.Controls.Add(this.cBStatusUPD);
            this.tabPage2.Controls.Add(this.label23);
            this.tabPage2.Controls.Add(this.label24);
            this.tabPage2.Controls.Add(this.tBnumtelORGUPD);
            this.tabPage2.Controls.Add(this.tBMailORGUPD);
            this.tabPage2.Controls.Add(this.tBOtchLPRUPD);
            this.tabPage2.Controls.Add(this.tBNameLPRUPG);
            this.tabPage2.Controls.Add(this.tBFamLPRUPD);
            this.tabPage2.Controls.Add(this.cBnumBildUPD);
            this.tabPage2.Controls.Add(this.cBStreetUPD);
            this.tabPage2.Controls.Add(this.cBCityUPD);
            this.tabPage2.Controls.Add(this.tBogrnUPD);
            this.tabPage2.Controls.Add(this.tBinnUPD);
            this.tabPage2.Controls.Add(this.cBNameORGUPD);
            this.tabPage2.Controls.Add(this.label20);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.label22);
            this.tabPage2.Controls.Add(this.label26);
            this.tabPage2.Controls.Add(this.label27);
            this.tabPage2.Controls.Add(this.label28);
            this.tabPage2.Controls.Add(this.label30);
            this.tabPage2.Controls.Add(this.label31);
            this.tabPage2.Controls.Add(this.label32);
            this.tabPage2.Controls.Add(this.label33);
            this.tabPage2.Controls.Add(this.label34);
            this.tabPage2.Controls.Add(this.label35);
            this.tabPage2.Controls.Add(this.label36);
            this.tabPage2.Controls.Add(this.label37);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(958, 186);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Изменить:";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(477, 2);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 13);
            this.label14.TabIndex = 58;
            this.label14.Text = "Район:";
            // 
            // cBRaionUPD
            // 
            this.cBRaionUPD.DataSource = this.fKRaionCityBindingSource1;
            this.cBRaionUPD.DisplayMember = "NameR";
            this.cBRaionUPD.FormattingEnabled = true;
            this.cBRaionUPD.Location = new System.Drawing.Point(477, 19);
            this.cBRaionUPD.Name = "cBRaionUPD";
            this.cBRaionUPD.Size = new System.Drawing.Size(121, 21);
            this.cBRaionUPD.TabIndex = 57;
            this.cBRaionUPD.ValueMember = "idRaion";
            // 
            // fKRaionCityBindingSource1
            // 
            this.fKRaionCityBindingSource1.DataMember = "FK_Raion_City";
            this.fKRaionCityBindingSource1.DataSource = this.cityBindingSource;
            // 
            // butUPD
            // 
            this.butUPD.Location = new System.Drawing.Point(736, 131);
            this.butUPD.Name = "butUPD";
            this.butUPD.Size = new System.Drawing.Size(75, 23);
            this.butUPD.TabIndex = 56;
            this.butUPD.Text = "Обновить";
            this.butUPD.UseVisualStyleBackColor = true;
            this.butUPD.Click += new System.EventHandler(this.butUPD_Click);
            // 
            // cBSotrOtchUPD
            // 
            this.cBSotrOtchUPD.DataSource = this.sotrydBindingSource1;
            this.cBSotrOtchUPD.DisplayMember = "ID";
            this.cBSotrOtchUPD.FormattingEnabled = true;
            this.cBSotrOtchUPD.Location = new System.Drawing.Point(266, 158);
            this.cBSotrOtchUPD.Name = "cBSotrOtchUPD";
            this.cBSotrOtchUPD.Size = new System.Drawing.Size(121, 21);
            this.cBSotrOtchUPD.TabIndex = 55;
            this.cBSotrOtchUPD.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // cBNameSotrUPD
            // 
            this.cBNameSotrUPD.DataSource = this.sotrydBindingSource1;
            this.cBNameSotrUPD.DisplayMember = "Name";
            this.cBNameSotrUPD.FormattingEnabled = true;
            this.cBNameSotrUPD.Location = new System.Drawing.Point(138, 158);
            this.cBNameSotrUPD.Name = "cBNameSotrUPD";
            this.cBNameSotrUPD.Size = new System.Drawing.Size(121, 21);
            this.cBNameSotrUPD.TabIndex = 54;
            this.cBNameSotrUPD.ValueMember = "ID";
            // 
            // cBSotrFamUPD
            // 
            this.cBSotrFamUPD.DataSource = this.sotrydBindingSource1;
            this.cBSotrFamUPD.DisplayMember = "Fam";
            this.cBSotrFamUPD.FormattingEnabled = true;
            this.cBSotrFamUPD.Location = new System.Drawing.Point(7, 158);
            this.cBSotrFamUPD.Name = "cBSotrFamUPD";
            this.cBSotrFamUPD.Size = new System.Drawing.Size(121, 21);
            this.cBSotrFamUPD.TabIndex = 53;
            this.cBSotrFamUPD.ValueMember = "ID";
            // 
            // tBDescORGUPD
            // 
            this.tBDescORGUPD.Location = new System.Drawing.Point(456, 105);
            this.tBDescORGUPD.Multiline = true;
            this.tBDescORGUPD.Name = "tBDescORGUPD";
            this.tBDescORGUPD.Size = new System.Drawing.Size(240, 75);
            this.tBDescORGUPD.TabIndex = 52;
            // 
            // cBStatusUPD
            // 
            this.cBStatusUPD.FormattingEnabled = true;
            this.cBStatusUPD.Items.AddRange(new object[] {
            "КП",
            "ПЕРЕГОВОРЫ",
            "СДЕЛКА",
            "ОТКАЗ"});
            this.cBStatusUPD.Location = new System.Drawing.Point(241, 105);
            this.cBStatusUPD.Name = "cBStatusUPD";
            this.cBStatusUPD.Size = new System.Drawing.Size(121, 21);
            this.cBStatusUPD.TabIndex = 51;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(453, 91);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(60, 13);
            this.label23.TabIndex = 50;
            this.label23.Text = "Описание:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(238, 91);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(44, 13);
            this.label24.TabIndex = 49;
            this.label24.Text = "Статус:";
            // 
            // tBnumtelORGUPD
            // 
            this.tBnumtelORGUPD.Location = new System.Drawing.Point(135, 107);
            this.tBnumtelORGUPD.Name = "tBnumtelORGUPD";
            this.tBnumtelORGUPD.Size = new System.Drawing.Size(100, 20);
            this.tBnumtelORGUPD.TabIndex = 48;
            // 
            // tBMailORGUPD
            // 
            this.tBMailORGUPD.Location = new System.Drawing.Point(7, 108);
            this.tBMailORGUPD.Name = "tBMailORGUPD";
            this.tBMailORGUPD.Size = new System.Drawing.Size(121, 20);
            this.tBMailORGUPD.TabIndex = 47;
            // 
            // tBOtchLPRUPD
            // 
            this.tBOtchLPRUPD.Location = new System.Drawing.Point(241, 62);
            this.tBOtchLPRUPD.Name = "tBOtchLPRUPD";
            this.tBOtchLPRUPD.Size = new System.Drawing.Size(100, 20);
            this.tBOtchLPRUPD.TabIndex = 46;
            // 
            // tBNameLPRUPG
            // 
            this.tBNameLPRUPG.Location = new System.Drawing.Point(135, 63);
            this.tBNameLPRUPG.Name = "tBNameLPRUPG";
            this.tBNameLPRUPG.Size = new System.Drawing.Size(100, 20);
            this.tBNameLPRUPG.TabIndex = 45;
            // 
            // tBFamLPRUPD
            // 
            this.tBFamLPRUPD.Location = new System.Drawing.Point(7, 63);
            this.tBFamLPRUPD.Name = "tBFamLPRUPD";
            this.tBFamLPRUPD.Size = new System.Drawing.Size(121, 20);
            this.tBFamLPRUPD.TabIndex = 44;
            // 
            // cBnumBildUPD
            // 
            this.cBnumBildUPD.DataSource = this.fKBildingStreetBindingSource1;
            this.cBnumBildUPD.DisplayMember = "number";
            this.cBnumBildUPD.FormattingEnabled = true;
            this.cBnumBildUPD.Location = new System.Drawing.Point(732, 19);
            this.cBnumBildUPD.Name = "cBnumBildUPD";
            this.cBnumBildUPD.Size = new System.Drawing.Size(121, 21);
            this.cBnumBildUPD.TabIndex = 43;
            this.cBnumBildUPD.ValueMember = "idBilding";
            // 
            // fKBildingStreetBindingSource1
            // 
            this.fKBildingStreetBindingSource1.DataMember = "FK_Bilding_Street";
            this.fKBildingStreetBindingSource1.DataSource = this.fKStreetRaionBindingSource1;
            // 
            // fKStreetRaionBindingSource1
            // 
            this.fKStreetRaionBindingSource1.DataMember = "FK_Street_Raion";
            this.fKStreetRaionBindingSource1.DataSource = this.fKRaionCityBindingSource1;
            // 
            // cBStreetUPD
            // 
            this.cBStreetUPD.DataSource = this.fKStreetRaionBindingSource1;
            this.cBStreetUPD.DisplayMember = "NameS";
            this.cBStreetUPD.FormattingEnabled = true;
            this.cBStreetUPD.Location = new System.Drawing.Point(604, 19);
            this.cBStreetUPD.Name = "cBStreetUPD";
            this.cBStreetUPD.Size = new System.Drawing.Size(121, 21);
            this.cBStreetUPD.TabIndex = 42;
            this.cBStreetUPD.ValueMember = "idStreet";
            // 
            // cBCityUPD
            // 
            this.cBCityUPD.DataSource = this.cityBindingSource;
            this.cBCityUPD.DisplayMember = "Name";
            this.cBCityUPD.FormattingEnabled = true;
            this.cBCityUPD.Location = new System.Drawing.Point(350, 20);
            this.cBCityUPD.Name = "cBCityUPD";
            this.cBCityUPD.Size = new System.Drawing.Size(121, 21);
            this.cBCityUPD.TabIndex = 41;
            this.cBCityUPD.ValueMember = "idCity";
            // 
            // tBogrnUPD
            // 
            this.tBogrnUPD.Location = new System.Drawing.Point(241, 21);
            this.tBogrnUPD.Name = "tBogrnUPD";
            this.tBogrnUPD.Size = new System.Drawing.Size(100, 20);
            this.tBogrnUPD.TabIndex = 40;
            // 
            // tBinnUPD
            // 
            this.tBinnUPD.Location = new System.Drawing.Point(135, 20);
            this.tBinnUPD.Name = "tBinnUPD";
            this.tBinnUPD.Size = new System.Drawing.Size(100, 20);
            this.tBinnUPD.TabIndex = 39;
            // 
            // cBNameORGUPD
            // 
            this.cBNameORGUPD.DataSource = this.oRGBindingSource;
            this.cBNameORGUPD.DisplayMember = "name";
            this.cBNameORGUPD.FormattingEnabled = true;
            this.cBNameORGUPD.Location = new System.Drawing.Point(7, 20);
            this.cBNameORGUPD.Name = "cBNameORGUPD";
            this.cBNameORGUPD.Size = new System.Drawing.Size(121, 21);
            this.cBNameORGUPD.TabIndex = 38;
            // 
            // oRGBindingSource
            // 
            this.oRGBindingSource.DataMember = "ORG";
            this.oRGBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(265, 141);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(118, 13);
            this.label20.TabIndex = 37;
            this.label20.Text = "Отчество сотрудника:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(132, 91);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(88, 13);
            this.label21.TabIndex = 36;
            this.label21.Text = "Номер тел ОРГ:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(9, 91);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(64, 13);
            this.label22.TabIndex = 35;
            this.label22.Text = "Почта ОРГ:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(238, 46);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(83, 13);
            this.label26.TabIndex = 31;
            this.label26.Text = "Отчество ЛПР:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(135, 46);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(58, 13);
            this.label27.TabIndex = 30;
            this.label27.Text = "Имя ЛПР:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(9, 46);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(85, 13);
            this.label28.TabIndex = 29;
            this.label28.Text = "Фамилия ЛПР:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(729, 2);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(73, 13);
            this.label30.TabIndex = 27;
            this.label30.Text = "Номер дома:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(601, 2);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(42, 13);
            this.label31.TabIndex = 26;
            this.label31.Text = "Улица:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(347, 3);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(98, 13);
            this.label32.TabIndex = 25;
            this.label32.Text = "Название города:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(9, 141);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(120, 13);
            this.label33.TabIndex = 24;
            this.label33.Text = "Фамилия сотрудника:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(135, 141);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(93, 13);
            this.label34.TabIndex = 23;
            this.label34.Text = "Имя сотрудника:";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(238, 3);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(39, 13);
            this.label35.TabIndex = 22;
            this.label35.Text = "ОГРН:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(135, 3);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(34, 13);
            this.label36.TabIndex = 21;
            this.label36.Text = "ИНН:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(9, 3);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(60, 13);
            this.label37.TabIndex = 20;
            this.label37.Text = "Название:";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.butDel);
            this.tabPage3.Controls.Add(this.cBOtchLPRDEL);
            this.tabPage3.Controls.Add(this.cBNAmeLPRDEL);
            this.tabPage3.Controls.Add(this.cBFamLPRDEL);
            this.tabPage3.Controls.Add(this.cBNameORGDEL);
            this.tabPage3.Controls.Add(this.label45);
            this.tabPage3.Controls.Add(this.label46);
            this.tabPage3.Controls.Add(this.label47);
            this.tabPage3.Controls.Add(this.label56);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(958, 186);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Удалить:";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // butDel
            // 
            this.butDel.Location = new System.Drawing.Point(15, 114);
            this.butDel.Name = "butDel";
            this.butDel.Size = new System.Drawing.Size(75, 23);
            this.butDel.TabIndex = 36;
            this.butDel.Text = "Удалить";
            this.butDel.UseVisualStyleBackColor = true;
            this.butDel.Click += new System.EventHandler(this.butDel_Click);
            // 
            // cBOtchLPRDEL
            // 
            this.cBOtchLPRDEL.DataSource = this.oRGMenBindingSource;
            this.cBOtchLPRDEL.DisplayMember = "otch";
            this.cBOtchLPRDEL.FormattingEnabled = true;
            this.cBOtchLPRDEL.Location = new System.Drawing.Point(289, 74);
            this.cBOtchLPRDEL.Name = "cBOtchLPRDEL";
            this.cBOtchLPRDEL.Size = new System.Drawing.Size(121, 21);
            this.cBOtchLPRDEL.TabIndex = 35;
            this.cBOtchLPRDEL.ValueMember = "id";
            // 
            // oRGMenBindingSource
            // 
            this.oRGMenBindingSource.DataMember = "ORGMen";
            this.oRGMenBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // cBNAmeLPRDEL
            // 
            this.cBNAmeLPRDEL.DataSource = this.oRGMenBindingSource;
            this.cBNAmeLPRDEL.DisplayMember = "name";
            this.cBNAmeLPRDEL.FormattingEnabled = true;
            this.cBNAmeLPRDEL.Location = new System.Drawing.Point(151, 74);
            this.cBNAmeLPRDEL.Name = "cBNAmeLPRDEL";
            this.cBNAmeLPRDEL.Size = new System.Drawing.Size(121, 21);
            this.cBNAmeLPRDEL.TabIndex = 34;
            this.cBNAmeLPRDEL.ValueMember = "id";
            // 
            // cBFamLPRDEL
            // 
            this.cBFamLPRDEL.DataSource = this.oRGMenBindingSource;
            this.cBFamLPRDEL.DisplayMember = "fam";
            this.cBFamLPRDEL.FormattingEnabled = true;
            this.cBFamLPRDEL.Location = new System.Drawing.Point(15, 75);
            this.cBFamLPRDEL.Name = "cBFamLPRDEL";
            this.cBFamLPRDEL.Size = new System.Drawing.Size(121, 21);
            this.cBFamLPRDEL.TabIndex = 33;
            this.cBFamLPRDEL.ValueMember = "id";
            // 
            // cBNameORGDEL
            // 
            this.cBNameORGDEL.DataSource = this.oRGBindingSource;
            this.cBNameORGDEL.DisplayMember = "name";
            this.cBNameORGDEL.FormattingEnabled = true;
            this.cBNameORGDEL.Location = new System.Drawing.Point(15, 27);
            this.cBNameORGDEL.Name = "cBNameORGDEL";
            this.cBNameORGDEL.Size = new System.Drawing.Size(121, 21);
            this.cBNameORGDEL.TabIndex = 32;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(286, 58);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(83, 13);
            this.label45.TabIndex = 31;
            this.label45.Text = "Отчество ЛПР:";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(148, 58);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(58, 13);
            this.label46.TabIndex = 30;
            this.label46.Text = "Имя ЛПР:";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(12, 58);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(85, 13);
            this.label47.TabIndex = 29;
            this.label47.Text = "Фамилия ЛПР:";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(12, 10);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(60, 13);
            this.label56.TabIndex = 20;
            this.label56.Text = "Название:";
            // 
            // sotrydBindingSource
            // 
            this.sotrydBindingSource.DataMember = "Sotryd";
            this.sotrydBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.названиеОрганизацииDataGridViewTextBoxColumn,
            this.статусDataGridViewTextBoxColumn,
            this.описаниеDataGridViewTextBoxColumn,
            this.фАМИЛИЯЛПРDataGridViewTextBoxColumn,
            this.иМЯЛПРDataGridViewTextBoxColumn,
            this.почтаЛПРDataGridViewTextBoxColumn,
            this.нормерТелЛПРDataGridViewTextBoxColumn,
            this.областьDataGridViewTextBoxColumn,
            this.районОбластиDataGridViewTextBoxColumn,
            this.населенныйПунктDataGridViewTextBoxColumn,
            this.названиеРнаГородаDataGridViewTextBoxColumn,
            this.улицаDataGridViewTextBoxColumn,
            this.номерДомаDataGridViewTextBoxColumn,
            this.технологияПредосталенияDataGridViewTextBoxColumn,
            this.технологияDataGridViewTextBoxColumn,
            this.почтаОрганизацииDataGridViewTextBoxColumn,
            this.номерТелефонаОргDataGridViewTextBoxColumn,
            this.фамилияСотрудникаDataGridViewTextBoxColumn,
            this.имяСотрудникаDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.oRGJoinBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(7, 219);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(958, 321);
            this.dataGridView1.TabIndex = 1;
            // 
            // названиеОрганизацииDataGridViewTextBoxColumn
            // 
            this.названиеОрганизацииDataGridViewTextBoxColumn.DataPropertyName = "Название организации";
            this.названиеОрганизацииDataGridViewTextBoxColumn.HeaderText = "Название организации";
            this.названиеОрганизацииDataGridViewTextBoxColumn.Name = "названиеОрганизацииDataGridViewTextBoxColumn";
            // 
            // статусDataGridViewTextBoxColumn
            // 
            this.статусDataGridViewTextBoxColumn.DataPropertyName = "Статус";
            this.статусDataGridViewTextBoxColumn.HeaderText = "Статус";
            this.статусDataGridViewTextBoxColumn.Name = "статусDataGridViewTextBoxColumn";
            // 
            // описаниеDataGridViewTextBoxColumn
            // 
            this.описаниеDataGridViewTextBoxColumn.DataPropertyName = "Описание";
            this.описаниеDataGridViewTextBoxColumn.HeaderText = "Описание";
            this.описаниеDataGridViewTextBoxColumn.Name = "описаниеDataGridViewTextBoxColumn";
            // 
            // фАМИЛИЯЛПРDataGridViewTextBoxColumn
            // 
            this.фАМИЛИЯЛПРDataGridViewTextBoxColumn.DataPropertyName = "ФАМИЛИЯ ЛПР";
            this.фАМИЛИЯЛПРDataGridViewTextBoxColumn.HeaderText = "ФАМИЛИЯ ЛПР";
            this.фАМИЛИЯЛПРDataGridViewTextBoxColumn.Name = "фАМИЛИЯЛПРDataGridViewTextBoxColumn";
            // 
            // иМЯЛПРDataGridViewTextBoxColumn
            // 
            this.иМЯЛПРDataGridViewTextBoxColumn.DataPropertyName = "ИМЯ ЛПР";
            this.иМЯЛПРDataGridViewTextBoxColumn.HeaderText = "ИМЯ ЛПР";
            this.иМЯЛПРDataGridViewTextBoxColumn.Name = "иМЯЛПРDataGridViewTextBoxColumn";
            // 
            // почтаЛПРDataGridViewTextBoxColumn
            // 
            this.почтаЛПРDataGridViewTextBoxColumn.DataPropertyName = "Почта ЛПР";
            this.почтаЛПРDataGridViewTextBoxColumn.HeaderText = "Почта ЛПР";
            this.почтаЛПРDataGridViewTextBoxColumn.Name = "почтаЛПРDataGridViewTextBoxColumn";
            // 
            // нормерТелЛПРDataGridViewTextBoxColumn
            // 
            this.нормерТелЛПРDataGridViewTextBoxColumn.DataPropertyName = "Нормер тел ЛПР";
            this.нормерТелЛПРDataGridViewTextBoxColumn.HeaderText = "Нормер тел ЛПР";
            this.нормерТелЛПРDataGridViewTextBoxColumn.Name = "нормерТелЛПРDataGridViewTextBoxColumn";
            // 
            // областьDataGridViewTextBoxColumn
            // 
            this.областьDataGridViewTextBoxColumn.DataPropertyName = "Область";
            this.областьDataGridViewTextBoxColumn.HeaderText = "Область";
            this.областьDataGridViewTextBoxColumn.Name = "областьDataGridViewTextBoxColumn";
            // 
            // районОбластиDataGridViewTextBoxColumn
            // 
            this.районОбластиDataGridViewTextBoxColumn.DataPropertyName = "Район области";
            this.районОбластиDataGridViewTextBoxColumn.HeaderText = "Район области";
            this.районОбластиDataGridViewTextBoxColumn.Name = "районОбластиDataGridViewTextBoxColumn";
            // 
            // населенныйПунктDataGridViewTextBoxColumn
            // 
            this.населенныйПунктDataGridViewTextBoxColumn.DataPropertyName = "Населенный пункт";
            this.населенныйПунктDataGridViewTextBoxColumn.HeaderText = "Населенный пункт";
            this.населенныйПунктDataGridViewTextBoxColumn.Name = "населенныйПунктDataGridViewTextBoxColumn";
            // 
            // названиеРнаГородаDataGridViewTextBoxColumn
            // 
            this.названиеРнаГородаDataGridViewTextBoxColumn.DataPropertyName = "Название р-на города";
            this.названиеРнаГородаDataGridViewTextBoxColumn.HeaderText = "Название р-на города";
            this.названиеРнаГородаDataGridViewTextBoxColumn.Name = "названиеРнаГородаDataGridViewTextBoxColumn";
            // 
            // улицаDataGridViewTextBoxColumn
            // 
            this.улицаDataGridViewTextBoxColumn.DataPropertyName = "Улица";
            this.улицаDataGridViewTextBoxColumn.HeaderText = "Улица";
            this.улицаDataGridViewTextBoxColumn.Name = "улицаDataGridViewTextBoxColumn";
            // 
            // номерДомаDataGridViewTextBoxColumn
            // 
            this.номерДомаDataGridViewTextBoxColumn.DataPropertyName = "Номер дома";
            this.номерДомаDataGridViewTextBoxColumn.HeaderText = "Номер дома";
            this.номерДомаDataGridViewTextBoxColumn.Name = "номерДомаDataGridViewTextBoxColumn";
            // 
            // технологияПредосталенияDataGridViewTextBoxColumn
            // 
            this.технологияПредосталенияDataGridViewTextBoxColumn.DataPropertyName = "Технология предосталения";
            this.технологияПредосталенияDataGridViewTextBoxColumn.HeaderText = "Технология предосталения";
            this.технологияПредосталенияDataGridViewTextBoxColumn.Name = "технологияПредосталенияDataGridViewTextBoxColumn";
            // 
            // технологияDataGridViewTextBoxColumn
            // 
            this.технологияDataGridViewTextBoxColumn.DataPropertyName = "Технология";
            this.технологияDataGridViewTextBoxColumn.HeaderText = "Технология";
            this.технологияDataGridViewTextBoxColumn.Name = "технологияDataGridViewTextBoxColumn";
            // 
            // почтаОрганизацииDataGridViewTextBoxColumn
            // 
            this.почтаОрганизацииDataGridViewTextBoxColumn.DataPropertyName = "Почта организации";
            this.почтаОрганизацииDataGridViewTextBoxColumn.HeaderText = "Почта организации";
            this.почтаОрганизацииDataGridViewTextBoxColumn.Name = "почтаОрганизацииDataGridViewTextBoxColumn";
            // 
            // номерТелефонаОргDataGridViewTextBoxColumn
            // 
            this.номерТелефонаОргDataGridViewTextBoxColumn.DataPropertyName = "Номер телефона орг";
            this.номерТелефонаОргDataGridViewTextBoxColumn.HeaderText = "Номер телефона орг";
            this.номерТелефонаОргDataGridViewTextBoxColumn.Name = "номерТелефонаОргDataGridViewTextBoxColumn";
            // 
            // фамилияСотрудникаDataGridViewTextBoxColumn
            // 
            this.фамилияСотрудникаDataGridViewTextBoxColumn.DataPropertyName = "Фамилия сотрудника";
            this.фамилияСотрудникаDataGridViewTextBoxColumn.HeaderText = "Фамилия сотрудника";
            this.фамилияСотрудникаDataGridViewTextBoxColumn.Name = "фамилияСотрудникаDataGridViewTextBoxColumn";
            // 
            // имяСотрудникаDataGridViewTextBoxColumn
            // 
            this.имяСотрудникаDataGridViewTextBoxColumn.DataPropertyName = "Имя сотрудника";
            this.имяСотрудникаDataGridViewTextBoxColumn.HeaderText = "Имя сотрудника";
            this.имяСотрудникаDataGridViewTextBoxColumn.Name = "имяСотрудникаDataGridViewTextBoxColumn";
            // 
            // oRGJoinBindingSource1
            // 
            this.oRGJoinBindingSource1.DataMember = "ORGJoin";
            this.oRGJoinBindingSource1.DataSource = this.baseLPRDataSet;
            // 
            // oRGJoinBindingSource
            // 
            this.oRGJoinBindingSource.DataMember = "ORGJoin";
            this.oRGJoinBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // cityTableAdapter
            // 
            this.cityTableAdapter.ClearBeforeFill = true;
            // 
            // raionTableAdapter
            // 
            this.raionTableAdapter.ClearBeforeFill = true;
            // 
            // streetTableAdapter
            // 
            this.streetTableAdapter.ClearBeforeFill = true;
            // 
            // bildingTableAdapter
            // 
            this.bildingTableAdapter.ClearBeforeFill = true;
            // 
            // oRGTableAdapter
            // 
            this.oRGTableAdapter.ClearBeforeFill = true;
            // 
            // oRGMenTableAdapter
            // 
            this.oRGMenTableAdapter.ClearBeforeFill = true;
            // 
            // sotrydTableAdapter
            // 
            this.sotrydTableAdapter.ClearBeforeFill = true;
            // 
            // oRGJoinTableAdapter
            // 
            this.oRGJoinTableAdapter.ClearBeforeFill = true;
            // 
            // FOrg
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(971, 552);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.tabControl1);
            this.Name = "FOrg";
            this.Text = "Форма организации";
            this.Load += new System.EventHandler(this.FOrg_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sotrydBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseLPRDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKRaionCityBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKBildingStreetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKStreetRaionBindingSource)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.fKRaionCityBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKBildingStreetBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKStreetRaionBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oRGBindingSource)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.oRGMenBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sotrydBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oRGJoinBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.oRGJoinBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button buttonADD;
        private System.Windows.Forms.ComboBox cBOtchSotrADD;
        private System.Windows.Forms.ComboBox cBNameSotrADD;
        private System.Windows.Forms.TextBox tBDescADD;
        private System.Windows.Forms.ComboBox cBFamSotrADD;
        private System.Windows.Forms.ComboBox cBStatusADD;
        private System.Windows.Forms.TextBox tBnumtelORGADD;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.TextBox tBMailADDORG;
        private System.Windows.Forms.TextBox tBnumtelLPRADD;
        private System.Windows.Forms.TextBox tBMailLPRADD;
        private System.Windows.Forms.TextBox tBOtchLPRADD;
        private System.Windows.Forms.TextBox tBNameLPRADD;
        private System.Windows.Forms.TextBox tBFamLPRADD;
        private System.Windows.Forms.TextBox tBIDLPRAdd;
        private System.Windows.Forms.ComboBox cBnumBildADDoRG;
        private System.Windows.Forms.ComboBox cBStreetAddORG;
        private System.Windows.Forms.ComboBox cBCityAddORG;
        private System.Windows.Forms.TextBox tBOGRNaddORG;
        private System.Windows.Forms.TextBox tBINNaddORG;
        private System.Windows.Forms.TextBox tBNameaddORG;
        private System.Windows.Forms.TextBox tBIDaddORG;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ComboBox cBSotrOtchUPD;
        private System.Windows.Forms.ComboBox cBNameSotrUPD;
        private System.Windows.Forms.ComboBox cBSotrFamUPD;
        private System.Windows.Forms.TextBox tBDescORGUPD;
        private System.Windows.Forms.ComboBox cBStatusUPD;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox tBnumtelORGUPD;
        private System.Windows.Forms.TextBox tBMailORGUPD;
        private System.Windows.Forms.TextBox tBOtchLPRUPD;
        private System.Windows.Forms.TextBox tBNameLPRUPG;
        private System.Windows.Forms.TextBox tBFamLPRUPD;
        private System.Windows.Forms.ComboBox cBnumBildUPD;
        private System.Windows.Forms.ComboBox cBStreetUPD;
        private System.Windows.Forms.ComboBox cBCityUPD;
        private System.Windows.Forms.TextBox tBogrnUPD;
        private System.Windows.Forms.TextBox tBinnUPD;
        private System.Windows.Forms.ComboBox cBNameORGUPD;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Button butUPD;
        private System.Windows.Forms.Button butDel;
        private System.Windows.Forms.ComboBox cBOtchLPRDEL;
        private System.Windows.Forms.ComboBox cBNAmeLPRDEL;
        private System.Windows.Forms.ComboBox cBFamLPRDEL;
        private System.Windows.Forms.ComboBox cBNameORGDEL;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn фамилияИмяСотрудникаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn сотрудникОрганизацииИКонтактыDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn информацияОЛПРDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource oRGJoinBindingSource;
        private BaseLPRDataSet baseLPRDataSet;
        private System.Windows.Forms.BindingSource cityBindingSource;
        private BaseLPRDataSetTableAdapters.CityTableAdapter cityTableAdapter;
        private System.Windows.Forms.BindingSource fKRaionCityBindingSource;
        private BaseLPRDataSetTableAdapters.RaionTableAdapter raionTableAdapter;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox cBRCAdd;
        private System.Windows.Forms.BindingSource fKStreetRaionBindingSource;
        private BaseLPRDataSetTableAdapters.StreetTableAdapter streetTableAdapter;
        private System.Windows.Forms.BindingSource fKBildingStreetBindingSource;
        private BaseLPRDataSetTableAdapters.BildingTableAdapter bildingTableAdapter;
        private System.Windows.Forms.BindingSource sotrydBindingSource;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox cBRaionUPD;
        private System.Windows.Forms.BindingSource fKRaionCityBindingSource1;
        private System.Windows.Forms.BindingSource fKBildingStreetBindingSource1;
        private System.Windows.Forms.BindingSource fKStreetRaionBindingSource1;
        private System.Windows.Forms.BindingSource oRGBindingSource;
        private BaseLPRDataSetTableAdapters.ORGTableAdapter oRGTableAdapter;
        private System.Windows.Forms.BindingSource oRGMenBindingSource;
        private BaseLPRDataSetTableAdapters.ORGMenTableAdapter oRGMenTableAdapter;
        private System.Windows.Forms.BindingSource sotrydBindingSource1;
        private BaseLPRDataSetTableAdapters.SotrydTableAdapter sotrydTableAdapter;
        private System.Windows.Forms.BindingSource oRGJoinBindingSource1;
        private BaseLPRDataSetTableAdapters.ORGJoinTableAdapter oRGJoinTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеОрганизацииDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn статусDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn описаниеDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn фАМИЛИЯЛПРDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn иМЯЛПРDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn почтаЛПРDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn нормерТелЛПРDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn областьDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn районОбластиDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn населенныйПунктDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеРнаГородаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn улицаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерДомаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn технологияПредосталенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn технологияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn почтаОрганизацииDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерТелефонаОргDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn фамилияСотрудникаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn имяСотрудникаDataGridViewTextBoxColumn;
        private System.Windows.Forms.CheckBox cBAddmail;
        private System.Windows.Forms.ComboBox cBSotrMailAdd;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
    }
}