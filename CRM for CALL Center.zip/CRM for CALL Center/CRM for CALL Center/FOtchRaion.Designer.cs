﻿namespace CRM_for_CALL_Center
{
    partial class FOtchRaion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cBCity = new System.Windows.Forms.ComboBox();
            this.cBRaion = new System.Windows.Forms.ComboBox();
            this.butSearch = new System.Windows.Forms.Button();
            this.butForm = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.baseLPRDataSet = new CRM_for_CALL_Center.BaseLPRDataSet();
            this.raionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.raionTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.RaionTableAdapter();
            this.raionJoinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.raionJoinTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.RaionJoinTableAdapter();
            this.bildJoinBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.населенныйПунктDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.названиеРнаГородаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерДомаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.технологияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cityTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.CityTableAdapter();
            this.fKRaionCityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bildJoinBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.baseLPRDataSet1 = new CRM_for_CALL_Center.BaseLPRDataSet();
            this.bildJoinBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.bildJoinTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.BildJoinTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseLPRDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.raionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.raionJoinBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bildJoinBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKRaionCityBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bildJoinBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseLPRDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bildJoinBindingSource2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Город:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(150, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Район:";
            // 
            // cBCity
            // 
            this.cBCity.DataSource = this.cityBindingSource;
            this.cBCity.DisplayMember = "Name";
            this.cBCity.FormattingEnabled = true;
            this.cBCity.Location = new System.Drawing.Point(16, 30);
            this.cBCity.Name = "cBCity";
            this.cBCity.Size = new System.Drawing.Size(121, 21);
            this.cBCity.TabIndex = 2;
            this.cBCity.ValueMember = "idCity";
            // 
            // cBRaion
            // 
            this.cBRaion.DataSource = this.fKRaionCityBindingSource;
            this.cBRaion.DisplayMember = "NameR";
            this.cBRaion.FormattingEnabled = true;
            this.cBRaion.Location = new System.Drawing.Point(153, 29);
            this.cBRaion.Name = "cBRaion";
            this.cBRaion.Size = new System.Drawing.Size(121, 21);
            this.cBRaion.TabIndex = 3;
            this.cBRaion.ValueMember = "idRaion";
            // 
            // butSearch
            // 
            this.butSearch.Location = new System.Drawing.Point(280, 27);
            this.butSearch.Name = "butSearch";
            this.butSearch.Size = new System.Drawing.Size(75, 23);
            this.butSearch.TabIndex = 4;
            this.butSearch.Text = "Поиск";
            this.butSearch.UseVisualStyleBackColor = true;
            this.butSearch.Click += new System.EventHandler(this.butSearch_Click);
            // 
            // butForm
            // 
            this.butForm.Location = new System.Drawing.Point(362, 27);
            this.butForm.Name = "butForm";
            this.butForm.Size = new System.Drawing.Size(103, 23);
            this.butForm.TabIndex = 5;
            this.butForm.Text = "Сформировать";
            this.butForm.UseVisualStyleBackColor = true;
            this.butForm.Click += new System.EventHandler(this.butForm_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.населенныйПунктDataGridViewTextBoxColumn,
            this.названиеРнаГородаDataGridViewTextBoxColumn,
            this.номерДомаDataGridViewTextBoxColumn,
            this.технологияDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.bildJoinBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(12, 57);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(768, 348);
            this.dataGridView1.TabIndex = 6;
            // 
            // baseLPRDataSet
            // 
            this.baseLPRDataSet.DataSetName = "BaseLPRDataSet";
            this.baseLPRDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // raionBindingSource
            // 
            this.raionBindingSource.DataMember = "Raion";
            this.raionBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // raionTableAdapter
            // 
            this.raionTableAdapter.ClearBeforeFill = true;
            // 
            // raionJoinBindingSource
            // 
            this.raionJoinBindingSource.DataMember = "RaionJoin";
            this.raionJoinBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // raionJoinTableAdapter
            // 
            this.raionJoinTableAdapter.ClearBeforeFill = true;
            // 
            // bildJoinBindingSource
            // 
            this.bildJoinBindingSource.DataMember = "BildJoin";
            this.bildJoinBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // населенныйПунктDataGridViewTextBoxColumn
            // 
            this.населенныйПунктDataGridViewTextBoxColumn.DataPropertyName = "Населенный пункт";
            this.населенныйПунктDataGridViewTextBoxColumn.HeaderText = "Населенный пункт";
            this.населенныйПунктDataGridViewTextBoxColumn.Name = "населенныйПунктDataGridViewTextBoxColumn";
            this.населенныйПунктDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // названиеРнаГородаDataGridViewTextBoxColumn
            // 
            this.названиеРнаГородаDataGridViewTextBoxColumn.DataPropertyName = "Название р-на города";
            this.названиеРнаГородаDataGridViewTextBoxColumn.HeaderText = "Название р-на города";
            this.названиеРнаГородаDataGridViewTextBoxColumn.Name = "названиеРнаГородаDataGridViewTextBoxColumn";
            // 
            // номерДомаDataGridViewTextBoxColumn
            // 
            this.номерДомаDataGridViewTextBoxColumn.DataPropertyName = "Номер дома";
            this.номерДомаDataGridViewTextBoxColumn.HeaderText = "Номер дома";
            this.номерДомаDataGridViewTextBoxColumn.Name = "номерДомаDataGridViewTextBoxColumn";
            this.номерДомаDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // технологияDataGridViewTextBoxColumn
            // 
            this.технологияDataGridViewTextBoxColumn.DataPropertyName = "Технология";
            this.технологияDataGridViewTextBoxColumn.HeaderText = "Технология";
            this.технологияDataGridViewTextBoxColumn.Name = "технологияDataGridViewTextBoxColumn";
            this.технологияDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // cityBindingSource
            // 
            this.cityBindingSource.DataMember = "City";
            this.cityBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // cityTableAdapter
            // 
            this.cityTableAdapter.ClearBeforeFill = true;
            // 
            // fKRaionCityBindingSource
            // 
            this.fKRaionCityBindingSource.DataMember = "FK_Raion_City";
            this.fKRaionCityBindingSource.DataSource = this.cityBindingSource;
            // 
            // bildJoinBindingSource1
            // 
            this.bildJoinBindingSource1.DataMember = "BildJoin";
            this.bildJoinBindingSource1.DataSource = this.baseLPRDataSet;
            // 
            // baseLPRDataSet1
            // 
            this.baseLPRDataSet1.DataSetName = "BaseLPRDataSet";
            this.baseLPRDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bildJoinBindingSource2
            // 
            this.bildJoinBindingSource2.DataMember = "BildJoin";
            this.bildJoinBindingSource2.DataSource = this.baseLPRDataSet1;
            // 
            // bildJoinTableAdapter
            // 
            this.bildJoinTableAdapter.ClearBeforeFill = true;
            // 
            // FOtchRaion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 417);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.butForm);
            this.Controls.Add(this.butSearch);
            this.Controls.Add(this.cBRaion);
            this.Controls.Add(this.cBCity);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FOtchRaion";
            this.Text = "Формирование отчета по району";
            this.Load += new System.EventHandler(this.FOtchRaion_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseLPRDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.raionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.raionJoinBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bildJoinBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fKRaionCityBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bildJoinBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseLPRDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bildJoinBindingSource2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cBCity;
        private System.Windows.Forms.ComboBox cBRaion;
        private System.Windows.Forms.Button butSearch;
        private System.Windows.Forms.Button butForm;
        private System.Windows.Forms.DataGridView dataGridView1;
        private BaseLPRDataSet baseLPRDataSet;
        private System.Windows.Forms.BindingSource raionBindingSource;
        private BaseLPRDataSetTableAdapters.RaionTableAdapter raionTableAdapter;
        private System.Windows.Forms.BindingSource raionJoinBindingSource;
        private BaseLPRDataSetTableAdapters.RaionJoinTableAdapter raionJoinTableAdapter;
        private System.Windows.Forms.BindingSource bildJoinBindingSource;
        private System.Windows.Forms.DataGridViewTextBoxColumn населенныйПунктDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn названиеРнаГородаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерДомаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn технологияDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource cityBindingSource;
        private BaseLPRDataSetTableAdapters.CityTableAdapter cityTableAdapter;
        private System.Windows.Forms.BindingSource fKRaionCityBindingSource;
        private System.Windows.Forms.BindingSource bildJoinBindingSource1;
        private BaseLPRDataSet baseLPRDataSet1;
        private System.Windows.Forms.BindingSource bildJoinBindingSource2;
        private BaseLPRDataSetTableAdapters.BildJoinTableAdapter bildJoinTableAdapter;
    }
}