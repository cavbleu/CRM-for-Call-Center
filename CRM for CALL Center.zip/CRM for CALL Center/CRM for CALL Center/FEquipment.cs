﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRM_for_CALL_Center
{
    public partial class FEquipment : Form
    {

        BaseLPRDataSetTableAdapters.QueriesTableAdapter queriesTAdap;
        public FEquipment()
        {
            InitializeComponent();
        }

        private void FEquipment_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.EquiJoin". При необходимости она может быть перемещена или удалена.
            this.equiJoinTableAdapter.Fill(this.baseLPRDataSet.EquiJoin);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            queriesTAdap = new BaseLPRDataSetTableAdapters.QueriesTableAdapter();
            if (tBID.Text == "" || tBName.Text == "")
            { MessageBox.Show("Не введен параметр!"); }
            else
            {
                try
                {
                    queriesTAdap.AddEquipment(Convert.ToInt32(tBID.Text), tBName.Text);
                    this.equiJoinTableAdapter.Fill(this.baseLPRDataSet.EquiJoin);
                    tBID.Clear();
                    tBName.Clear();
                    this.equiJoinTableAdapter.Adapter.Update(this.baseLPRDataSet.EquiJoin);
                }
                catch { MessageBox.Show("Данные не добавлены!"); }
            }
        }
    }
}
