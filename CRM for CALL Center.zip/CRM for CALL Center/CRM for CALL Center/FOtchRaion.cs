﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using Word = Microsoft.Office.Interop.Word;
using Excel = Microsoft.Office.Interop.Excel;
using System.Reflection;
using System.IO;

namespace CRM_for_CALL_Center
{
    public partial class FOtchRaion : Form
    {
        Microsoft.Office.Interop.Word.Application wordApp;
        Microsoft.Office.Interop.Word.Document wordDoc;
        Microsoft.Office.Interop.Word.Paragraph wordParag;
        Microsoft.Office.Interop.Word.Table wordTable;
        public FOtchRaion()
        {
            InitializeComponent();

            wordApp = new Microsoft.Office.Interop.Word.Application();
        }

        private void FOtchRaion_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.City". При необходимости она может быть перемещена или удалена.
            this.cityTableAdapter.Fill(this.baseLPRDataSet.City);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.RaionJoin". При необходимости она может быть перемещена или удалена.
            this.raionJoinTableAdapter.Fill(this.baseLPRDataSet.RaionJoin);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.Raion". При необходимости она может быть перемещена или удалена.
            this.raionTableAdapter.Fill(this.baseLPRDataSet.Raion);
            this.bildJoinTableAdapter.Fill(this.baseLPRDataSet.BildJoin,cBCity.Text);

        }

        private void butSearch_Click(object sender, EventArgs e)
        {
            this.bildJoinTableAdapter.Fill(this.baseLPRDataSet.BildJoin, cBCity.Text);
        }

        private void butForm_Click(object sender, EventArgs e)
        {
            this.bildJoinTableAdapter.Fill(this.baseLPRDataSet.BildJoin, cBCity.Text);
            try
            {
                int row_count = dataGridView1.RowCount;
                int col_count = dataGridView1.ColumnCount;
                wordDoc = wordApp.Documents.Add(Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                wordParag = wordDoc.Paragraphs.Add(Type.Missing);
                wordParag.Range.Font.Name = "Calibri";
                wordParag.Range.Font.Size = 16;
                wordParag.Range.Font.Bold = 1;
                wordParag.Range.Text = $"Данные об организациях в городе '{cBCity.Text}' и районе города '{cBRaion.Text}'";
                wordParag.Range.Paragraphs.Alignment = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphCenter;

                wordDoc.Paragraphs.Add(Type.Missing);
                wordParag.Range.Tables.Add(wordParag.Range, row_count + 1, col_count, Type.Missing, Type.Missing);
                wordTable = wordDoc.Tables[1];
                wordTable.Range.Font.Bold = 1;
                wordTable.Range.Font.Size = 12;
                for (int j = 0; j < col_count; j++)
                {
                    var cell = dataGridView1.Columns[j].HeaderText;
                    wordTable.Cell(1, j + 1).Range.Text = cell;
                }
                wordDoc.Paragraphs.Add(Type.Missing);
                for (int i = 0; i < row_count - 1; i++)
                    for (int j = 0; j < col_count; j++)
                    {
                        var cell = dataGridView1.Rows[i].Cells[j];
                        wordTable.Cell(i + 2, j + 1).Range.Text = cell.Value.ToString();
                    }
                string put = Convert.ToString(@"C:\\Users\" + Environment.UserName + @"\Desktop\" + "Города в работе " + DateTime.Now.Date.Day.ToString() + " " + DateTime.Now.Date.Month.ToString() + " " + DateTime.Now.Date.Year.ToString() + ".doc");
                wordDoc.SaveAs(put);
                wordApp.ActiveDocument.Close();
                wordApp.Quit();
                MessageBox.Show("Данные выгружены в путь " + put);
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Данные не выгружены");
            }
        }
    }
}
