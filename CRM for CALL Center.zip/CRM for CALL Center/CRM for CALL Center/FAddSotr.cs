﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CRM_for_CALL_Center
{
    public partial class FAddSotr : Form
    {
        const string cString = @"Data Source=DESKTOP-N3GA48P\SQLEXPRESS;Initial Catalog=BaseLPR;Integrated Security=True";
        BaseLPRDataSetTableAdapters.QueriesTableAdapter queriesTAdap;
        public FAddSotr()
        {
            InitializeComponent();
        }

        private void FAddSotr_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.SOTRJOIN". При необходимости она может быть перемещена или удалена.
            this.sOTRJOINTableAdapter.Fill(this.baseLPRDataSet.SOTRJOIN);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.autorization". При необходимости она может быть перемещена или удалена.
            this.autorizationTableAdapter.Fill(this.baseLPRDataSet.autorization);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.SotrydJoin". При необходимости она может быть перемещена или удалена.
            this.sotrydJoinTableAdapter.Fill(this.baseLPRDataSet.SotrydJoin);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.Sotryd". При необходимости она может быть перемещена или удалена.
            this.sotrydTableAdapter.Fill(this.baseLPRDataSet.Sotryd);

        }

        private void butAdd_Click(object sender, EventArgs e)
        {
            queriesTAdap = new BaseLPRDataSetTableAdapters.QueriesTableAdapter();
            if (tBID.Text == "" || tBNameAdd.Text == "" || tBFamAdd.Text == "" ||
                tBOtchAdd.Text == "" || cBType.Text == "" || tBMailAdd.Text == "" ||
                tBNumAdd.Text == "" || tBLogin.Text == "" || tBPass.Text == "")
            { MessageBox.Show("Не введен параметр!"); }
            else
            {
                try
                {
                    
                    queriesTAdap.AddSotr(Convert.ToInt32(tBID.Text), tBNameAdd.Text, tBFamAdd.Text, tBOtchAdd.Text,
                        tBMailAdd.Text, tBNumAdd.Text);
                    this.sotrydTableAdapter.Fill(this.baseLPRDataSet.Sotryd);
                    this.sotrydTableAdapter.Adapter.Update(this.baseLPRDataSet.Sotryd);
                }
                catch { MessageBox.Show("Данные не добавлены!"); }
                try
                {
                    queriesTAdap.AddAuto(Convert.ToInt32(tBID.Text), tBLogin.Text, tBPass.Text, cBType.Text);
                    this.autorizationTableAdapter.Adapter.Update(this.baseLPRDataSet.autorization);
                    this.sotrydTableAdapter.Fill(this.baseLPRDataSet.Sotryd);
                    this.sotrydTableAdapter.Adapter.Update(this.baseLPRDataSet.SOTRJOIN);

                }
                catch { MessageBox.Show("Данные не добавлены!"); }
            }
            
        }

        private void butUpd_Click(object sender, EventArgs e)
        {
            queriesTAdap = new BaseLPRDataSetTableAdapters.QueriesTableAdapter();
            if (cBFamUPD.Text == "" || cBNameUpd.Text == "" || cBOtchUPD.Text == "" || tBMailUPD.Text == ""
                || tBNumUPD.Text == "")
            { MessageBox.Show("Не введен параметр!"); }
            else
            {
                try
                {
                    queriesTAdap.UPDSotr(cBNameUpd.Text, cBFamUPD.Text, 
                        cBOtchUPD.Text, tBMailUPD.Text, tBNumUPD.Text);

                    this.autorizationTableAdapter.Adapter.Update(this.baseLPRDataSet.autorization);
                    this.sotrydTableAdapter.Fill(this.baseLPRDataSet.Sotryd);
                    this.sotrydTableAdapter.Adapter.Update(this.baseLPRDataSet.SOTRJOIN);
                }
                catch { MessageBox.Show("Данные не изменены!"); }
            }
        }

        private void butUPDAuto_Click(object sender, EventArgs e)
        {
            if (cBLogUPD.Text == "" || tBPassUPD.Text == "" || cBTYPEupd.Text == "")
            {
                MessageBox.Show("Не введен параметр!");
            }
            else
            {
                try
                {
                    queriesTAdap.UPDAuto(tBLogin.Text, tBPass.Text, cBType.Text);
                    this.autorizationTableAdapter.Adapter.Update(this.baseLPRDataSet.autorization);
                    this.sotrydTableAdapter.Fill(this.baseLPRDataSet.Sotryd);
                    this.sotrydTableAdapter.Adapter.Update(this.baseLPRDataSet.SOTRJOIN);
                }
                catch { MessageBox.Show("Данные не изменены!"); }

            }
        }

        private void butDELauto_Click(object sender, EventArgs e)
        {
            if (cBLogUPD.Text == "")
            {
                MessageBox.Show("Не введен параметры!");
            }
            else
            {
                try
                {
                    queriesTAdap.DELAuto(tBLogin.Text, tBPass.Text, cBType.Text);
                    this.autorizationTableAdapter.Adapter.Update(this.baseLPRDataSet.autorization);
                    this.sotrydTableAdapter.Fill(this.baseLPRDataSet.Sotryd);
                    this.sotrydTableAdapter.Adapter.Update(this.baseLPRDataSet.SOTRJOIN);
                }
                catch { MessageBox.Show("Данные не удалены!"); }

            }
        }
    }
}
