﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace CRM_for_CALL_Center
{
    public partial class Form1 : Form
    {
        const string cString = @"Data Source=DESKTOP-N3GA48P\SQLEXPRESS;Initial Catalog=BaseLPR;Integrated Security=True";
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection(cString);
            cn.Open();
            string login = textBoxLogin.Text;
            string pass = textBoxPass.Text;
            string cmdSql = $"Select type1 from autorization where Login1='{login}' and Pass = '{pass}'";
            SqlCommand cmd = new SqlCommand(cmdSql,cn);
            SqlDataReader dr;
            SqlDataAdapter sda = new SqlDataAdapter(cmdSql,cn);
            DataTable dt = new System.Data.DataTable();
            sda.Fill(dt);
            dr = cmd.ExecuteReader();
            int count = 0;
            while (dr.Read())
            {
                count += 1;
            }
            if (count == 1)
            {
                switch (dt.Rows[0]["type1"] as string)
                {
                    case "admin":
                        {
                            MessageBox.Show("Вы успешно авторизованы");
                            this.Hide();
                            FAdminG fA = new FAdminG();
                            fA.Show();
                            break;
                        }

                    case "user":
                        {
                            MessageBox.Show("Вы успешно авторизованы");
                            this.Hide();
                            FUserG fU = new FUserG();
                            fU.Show();
                            break;
                        }

                    default:
                        {
                            MessageBox.Show("Пользователь не найден или обнаружено несоответсвие роли");
                            // ... handle unexpected roles here...
                            break;
                        }

                }
            }
            else if (count > 0)
            {
                MessageBox.Show("Пользователь не найден");
            }
            else
            {
                MessageBox.Show("Неправильный логин или пароль");
            }
            textBoxLogin.Clear();
            textBoxPass.Clear();
        }
    }
}
