﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRM_for_CALL_Center
{
    public partial class FAddStreet : Form
    {

        BaseLPRDataSetTableAdapters.QueriesTableAdapter queriesTAdap;
        public FAddStreet()
        {
            InitializeComponent();
        }

        private void FAddStreet_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.Raion". При необходимости она может быть перемещена или удалена.
            this.raionTableAdapter.Fill(this.baseLPRDataSet.Raion);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.City". При необходимости она может быть перемещена или удалена.
            this.cityTableAdapter.Fill(this.baseLPRDataSet.City);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.Street". При необходимости она может быть перемещена или удалена.
            this.streetTableAdapter.Fill(this.baseLPRDataSet.Street);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            queriesTAdap = new BaseLPRDataSetTableAdapters.QueriesTableAdapter();
            if ( tBID.Text == "" || cBRCity.Text =="" || tBStreet.Name == "" || cBCity.Text == "")
            { MessageBox.Show("Не введен параметр!"); }
            else
            {
                try
                {
                    queriesTAdap.AddStreet(Convert.ToInt32(tBID.Text), tBStreet.Text, cBCity.Text, cBRCity.Text);
                    this.streetTableAdapter.Fill(this.baseLPRDataSet.Street);
                    tBID.Clear();
                    tBStreet.Clear();

                    this.streetTableAdapter.Adapter.Update(this.baseLPRDataSet.Street);
                }
                catch { MessageBox.Show("Данные не добавлены!"); }
            }
        }
    }
}
