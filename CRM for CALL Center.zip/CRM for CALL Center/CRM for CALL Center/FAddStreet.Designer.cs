﻿namespace CRM_for_CALL_Center
{
    partial class FAddStreet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tBID = new System.Windows.Forms.TextBox();
            this.cBRCity = new System.Windows.Forms.ComboBox();
            this.cityBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.baseLPRDataSet = new CRM_for_CALL_Center.BaseLPRDataSet();
            this.tBStreet = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.streetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.streetTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.StreetTableAdapter();
            this.cityTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.CityTableAdapter();
            this.label4 = new System.Windows.Forms.Label();
            this.cBCity = new System.Windows.Forms.ComboBox();
            this.raionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.raionTableAdapter = new CRM_for_CALL_Center.BaseLPRDataSetTableAdapters.RaionTableAdapter();
            this.idStreetDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idRaionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameSDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseLPRDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.streetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.raionBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(251, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(137, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Название района города:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(406, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(42, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Улица:";
            // 
            // tBID
            // 
            this.tBID.Location = new System.Drawing.Point(13, 26);
            this.tBID.Name = "tBID";
            this.tBID.Size = new System.Drawing.Size(100, 20);
            this.tBID.TabIndex = 3;
            // 
            // cBRCity
            // 
            this.cBRCity.DataSource = this.raionBindingSource;
            this.cBRCity.DisplayMember = "NameR";
            this.cBRCity.FormattingEnabled = true;
            this.cBRCity.Location = new System.Drawing.Point(254, 25);
            this.cBRCity.Name = "cBRCity";
            this.cBRCity.Size = new System.Drawing.Size(148, 21);
            this.cBRCity.TabIndex = 4;
            this.cBRCity.ValueMember = "idCity";
            // 
            // cityBindingSource
            // 
            this.cityBindingSource.DataMember = "City";
            this.cityBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // baseLPRDataSet
            // 
            this.baseLPRDataSet.DataSetName = "BaseLPRDataSet";
            this.baseLPRDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tBStreet
            // 
            this.tBStreet.Location = new System.Drawing.Point(409, 26);
            this.tBStreet.Name = "tBStreet";
            this.tBStreet.Size = new System.Drawing.Size(132, 20);
            this.tBStreet.TabIndex = 5;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(560, 23);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "Добавить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idStreetDataGridViewTextBoxColumn,
            this.idRaionDataGridViewTextBoxColumn,
            this.nameSDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.streetBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(13, 53);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(659, 320);
            this.dataGridView1.TabIndex = 7;
            // 
            // streetBindingSource
            // 
            this.streetBindingSource.DataMember = "Street";
            this.streetBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // streetTableAdapter
            // 
            this.streetTableAdapter.ClearBeforeFill = true;
            // 
            // cityTableAdapter
            // 
            this.cityTableAdapter.ClearBeforeFill = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(120, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Город:";
            // 
            // cBCity
            // 
            this.cBCity.DataSource = this.cityBindingSource;
            this.cBCity.DisplayMember = "Name";
            this.cBCity.FormattingEnabled = true;
            this.cBCity.Location = new System.Drawing.Point(123, 26);
            this.cBCity.Name = "cBCity";
            this.cBCity.Size = new System.Drawing.Size(121, 21);
            this.cBCity.TabIndex = 9;
            // 
            // raionBindingSource
            // 
            this.raionBindingSource.DataMember = "Raion";
            this.raionBindingSource.DataSource = this.baseLPRDataSet;
            // 
            // raionTableAdapter
            // 
            this.raionTableAdapter.ClearBeforeFill = true;
            // 
            // idStreetDataGridViewTextBoxColumn
            // 
            this.idStreetDataGridViewTextBoxColumn.DataPropertyName = "idStreet";
            this.idStreetDataGridViewTextBoxColumn.HeaderText = "id УЛИЦЫ";
            this.idStreetDataGridViewTextBoxColumn.Name = "idStreetDataGridViewTextBoxColumn";
            // 
            // idRaionDataGridViewTextBoxColumn
            // 
            this.idRaionDataGridViewTextBoxColumn.DataPropertyName = "idRaion";
            this.idRaionDataGridViewTextBoxColumn.HeaderText = "id РАЙОНА ГОРОДА";
            this.idRaionDataGridViewTextBoxColumn.Name = "idRaionDataGridViewTextBoxColumn";
            this.idRaionDataGridViewTextBoxColumn.Width = 200;
            // 
            // nameSDataGridViewTextBoxColumn
            // 
            this.nameSDataGridViewTextBoxColumn.DataPropertyName = "NameS";
            this.nameSDataGridViewTextBoxColumn.HeaderText = "НАЗВАНИЕ УЛИЦЫ";
            this.nameSDataGridViewTextBoxColumn.Name = "nameSDataGridViewTextBoxColumn";
            this.nameSDataGridViewTextBoxColumn.Width = 200;
            // 
            // FAddStreet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 385);
            this.Controls.Add(this.cBCity);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tBStreet);
            this.Controls.Add(this.cBRCity);
            this.Controls.Add(this.tBID);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FAddStreet";
            this.Text = "Добавление улицы:";
            this.Load += new System.EventHandler(this.FAddStreet_Load);
            ((System.ComponentModel.ISupportInitialize)(this.cityBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baseLPRDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.streetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.raionBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tBID;
        private System.Windows.Forms.ComboBox cBRCity;
        private System.Windows.Forms.TextBox tBStreet;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private BaseLPRDataSet baseLPRDataSet;
        private System.Windows.Forms.BindingSource streetBindingSource;
        private BaseLPRDataSetTableAdapters.StreetTableAdapter streetTableAdapter;
        private System.Windows.Forms.BindingSource cityBindingSource;
        private BaseLPRDataSetTableAdapters.CityTableAdapter cityTableAdapter;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cBCity;
        private System.Windows.Forms.BindingSource raionBindingSource;
        private BaseLPRDataSetTableAdapters.RaionTableAdapter raionTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idStreetDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn idRaionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameSDataGridViewTextBoxColumn;
    }
}