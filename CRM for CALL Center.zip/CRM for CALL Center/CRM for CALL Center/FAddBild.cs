﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRM_for_CALL_Center
{
    public partial class FAddBild : Form
    {
        BaseLPRDataSetTableAdapters.QueriesTableAdapter queriesTAdap;
        public FAddBild()
        {
        
            InitializeComponent();
        }

        private void butAdd_Click(object sender, EventArgs e)
        {
            queriesTAdap = new BaseLPRDataSetTableAdapters.QueriesTableAdapter();
            if (tBID.Text == "" || cBCity.Text == "" || cBNameStreet.Text == "" || tBNumBild.Text == "" || tBcountP.Text == "" || cBtPred.Text == ""
                || cBnEq.Text == "" || cBtCab.Text == "" || cBRc.Text=="")
            { MessageBox.Show("Не введен параметр!"); }
            else
            {
                try
                {
                    queriesTAdap.AddHouseStreet(Convert.ToInt32(tBID.Text), tBNumBild.Text,cBCity.Text,cBRc.Text, cBNameStreet.Text, cBnEq.Text, cBtCab.Text,Convert.ToInt32(tBcountP.Text),cBtPred.Text);
                    this.bildingTableAdapter.Fill(this.baseLPRDataSet.Bilding);
                    tBID.Clear();
                    tBNumBild.Clear();
                    tBcountP.Clear();

                    this.bildingTableAdapter.Adapter.Update(this.baseLPRDataSet.Bilding);
                }
                catch { MessageBox.Show("Данные не добавлены!"); }
            }
        }

        private void FAddBild_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.ORG". При необходимости она может быть перемещена или удалена.
            this.oRGTableAdapter.Fill(this.baseLPRDataSet.ORG);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.Raion". При необходимости она может быть перемещена или удалена.
            this.raionTableAdapter.Fill(this.baseLPRDataSet.Raion);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.Bilding". При необходимости она может быть перемещена или удалена.
            this.bildingTableAdapter.Fill(this.baseLPRDataSet.Bilding);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.EquiJoin". При необходимости она может быть перемещена или удалена.
            this.equiJoinTableAdapter.Fill(this.baseLPRDataSet.EquiJoin);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.Street". При необходимости она может быть перемещена или удалена.
            this.streetTableAdapter.Fill(this.baseLPRDataSet.Street);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "baseLPRDataSet.City". При необходимости она может быть перемещена или удалена.
            this.cityTableAdapter.Fill(this.baseLPRDataSet.City);

        }

        private void butUPG_Click(object sender, EventArgs e)
        {
            queriesTAdap = new BaseLPRDataSetTableAdapters.QueriesTableAdapter();
            if (tBportUPD.Text == "" || cBnumBUPD.Text=="" || cBCityUPD.Text == "" || cBStreetUPD.Text == "" || cBRcityUPD .Text == "" || cBtechUPD.Text == "" || cBtechCUPD.Text == "" || cBEqUPD.Text == "")
            { MessageBox.Show("Не введен параметр!"); }
            else
            {
                try
                {
                    queriesTAdap.UPDHouseStreet(cBnumBUPD.Text,cBRcityUPD.Text, cBCityUPD.Text, cBNameStreet.Text, 
                        cBEqUPD.Text, cBtechCUPD.Text, Convert.ToInt32(tBportUPD.Text), cBtechUPD.Text);
                    this.bildingTableAdapter.Fill(this.baseLPRDataSet.Bilding);
                    tBportUPD.Clear();

                    this.bildingTableAdapter.Adapter.Update(this.baseLPRDataSet.Bilding);
                }
                catch { MessageBox.Show("Данные не обновлены!"); }
            }
        }

        private void butDEL_Click(object sender, EventArgs e)
        {
            queriesTAdap = new BaseLPRDataSetTableAdapters.QueriesTableAdapter();
            if (cBCityDEL.Text == "" || cBStreetDEL.Text == "" || cBnumBDEL.Text == "" || cBRCityDel.Text =="")
            { MessageBox.Show("Не введен параметр!"); }
            else
            {
                try
                {
                    queriesTAdap.Delbilding(cBCityDEL.Text,cBRCityDel.Text, cBStreetDEL.Text, cBnumBDEL.Text);
                    this.bildingTableAdapter.Fill(this.baseLPRDataSet.Bilding);

                    this.bildingTableAdapter.Adapter.Update(this.baseLPRDataSet.Bilding);
                }
                catch { MessageBox.Show("Данные не удалены!"); }
            }
        }
    }
}
