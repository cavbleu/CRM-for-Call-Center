﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRM_for_CALL_Center
{
    public partial class FUserG : Form
    {
        public FUserG()
        {
            InitializeComponent();
        }

        private void bFilter_Click(object sender, EventArgs e)
        {
            this.oRGJoinTableAdapter.Fill(this.baseLPRDataSet.ORGJoin, "","","","","","","");
            this.oRGJoinTableAdapter.Adapter.Update(this.baseLPRDataSet.ORGJoin);
        }

        private void FAdminG_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void добавитьОбластьToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FAddOBL f = new FAddOBL();
            f.Show();
        }

        private void добавитьРайонОбластиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FAddRaion f = new FAddRaion();
            f.Show();
        }

        private void добавитьГородToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FAddCity f = new FAddCity();
            f.Show();
        }

        private void добавитьРайонГородаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FAddRCity f = new FAddRCity();
            f.Show();
        }

        private void добавитьУлицуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FAddStreet f = new FAddStreet();
            f.Show();
        }

        private void добавитьДомToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FAddBild f = new FAddBild();
            f.Show();
        }

        private void добавитьОборудованиеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FEquipment f = new FEquipment();
            f.Show();
        }

        private void добавитьОрганизациюToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FOrg f = new FOrg();
            f.Show();
        }

        private void добавитьСотрудникаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FAddSotr f = new FAddSotr();
            f.Show();
        }

        private void формированиеОтчетаПоГородуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FOtchCity f = new FOtchCity();
            f.Show();
        }

        private void формированиеОтчетаПоРайонуГородаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FOtchRaion f = new FOtchRaion();
            f.Show();
        }

        private void формированиеОтчетаПоОрганизацииToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FOtchORG f = new FOtchORG();
            f.Show();
        }
        

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        
    }
}
