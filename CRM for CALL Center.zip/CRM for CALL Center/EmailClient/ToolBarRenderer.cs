﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EmailClient
{
    public class ToolBarRenderer : ToolStripProfessionalRenderer
    {
        // Default Constructor
        public ToolBarRenderer()
        {

        }

        // Just would not draw Border
        protected override void OnRenderToolStripBorder(ToolStripRenderEventArgs e)
        {

        }

        // just don't draw background
        protected override void OnRenderToolStripBackground(ToolStripRenderEventArgs e)
        {

        }
    }
}
